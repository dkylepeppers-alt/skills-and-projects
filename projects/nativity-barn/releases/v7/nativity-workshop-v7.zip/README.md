# Nativity barn — Revision 7 (1-1/4-inch frame)

Enlarged miniature timber-frame barn with the same 24 x 12 inch roof footprint
as Revision 6. Overall height including the 15/32 deck is 19.108 in.
The horizontal centerlines and asymmetric king-post configuration are retained.
See the design brief for the exact resizing rule and all joinery assumptions.

## Files

- **nativity-construction-plans-v7.pdf** — 116 bookmarked ANSI B (17 x 11)
  construction drawings: assembly views, enlarged joint sections, individual
  timber and conventional arrow-dimensioned feature details, cladding and peg
  schedules, and cut list. All dimensions are actual inches.
- **nativity-patterns-v7.pdf** — 34 landscape US Letter 1:1 pattern sheets
  from the same CAD geometry. Print Actual Size (100%); measure the calibration
  square in both directions. Align matching A/B/C crosses at the 1-inch
  overlaps. Use the construction drawings for all blind dimensions.
- **nativity_v7.step** — complete labeled CAD model. For OCP Viewer,
  start the viewer with `python -m ocp_viewer`, then in a second shell
  run the command below. Use `previews/frame.step` to see the uncovered frame.
- **previews/** — shaded CAD assembly, frame and bearing detail previews.
- **patterns/** — source SVG/DXF true-size profiles and corner developments.
- **shop-data.md** — corner offsets, saw settings and material/fit notes.
- **source/** — parametric model, drawing/pattern generators and verification
  code. Bundled geometry/drafting helpers enable the project to reproduce
  outside ChatGPT.
- **validation/** — geometry, coverage, drawing and print verification results.

```sh
python -c "from build123d import import_step; from ocp_viewer import show; show(import_step('nativity_v7.step'))"
```

## Reproduce

From the extracted package, use Python 3.11+ and a dedicated virtual
environment. The model was generated with build123d 0.13.0. All drawing
scripts use the same BREP solids. Install the Liberation Sans fonts if not
already available; on Debian: package `fonts-liberation`.

```sh
python3 -m venv .venv
.venv/bin/pip install -r source/requirements.txt
.venv/bin/python source/verify_v7.py
.venv/bin/python source/render_previews.py
.venv/bin/python source/shop_data.py
.venv/bin/python source/patterns_v7.py
.venv/bin/python source/draw_v7.py
.venv/bin/python source/verify_export.py
.venv/bin/python source/check_drawings.py
```

Mill to the stated stock cross-sections; dry-fit shoulders while keeping
depth relief clear; drill the pegs in assembled joints. Retain the original
V6 drawings only for comparison: all layout dimensions and templates are newly
generated for V7.
