# Revision 7: enlarged frame design basis

## Fixed geometry and resizing rule

The roof plan remains exactly 24 x 12 in and the plywood deck 23 x 11 in.
Post centers remain X 1-1/4, 16-1/4 and 22-3/4; Y 1-1/2 and 10-1/2.
The asymmetrical gable, open left bay, lower right stall and lift-off roof
panels remain. All dimensions are actual miniature dimensions in inches.

The finished main post, plate and tie cross-section increases from 1 in to
1-1/4 in square. Structural sections and nominal vertical elevations are scaled
by 5/4. Horizontal spans are recalculated around the same post centers, not
globally scaled. Roof pitch rises from 6:12 to 7-1/2:12 (32.005 degrees). The
ridge underside is lowered 5/64 in from literal vertical scaling so all three
rafter support seats bear across the complete enlarged support width.

| Component | Revision 7 actual stock |
| --- | --- |
| Posts, plates, ties | 1-1/4 x 1-1/4 |
| Principal rafters | 1-1/4 x 1-3/32 normal to pitch |
| Knee braces, gable struts, rails | 5/8 x 5/8 |
| Purlins | 15/32 square |
| Roof boards | 5/32 thick, 1.184375 wide, 10 per panel |
| Rear boards | 5/64 thick, 0.932292 wide, 24 total |
| Deck | 15/32 actual thickness (nominal 1/2 plywood) |
| Main pegs | 1/8 diameter, selected standard drill size |
| Small pegs | 5/64 diameter |

Deck-top datum Z=0. Main plate soffits Z 10-5/8; main tie soffit Z 11-1/4;
main tie top Z 12-1/2; lower stall plate top Z 8-7/16. Roof underside ridge
Z 16-51/64. Ridge surface height 18.63945 in above deck; total envelope
including deck 19.10820 in.

Grain direction and roll are fixed in each part frame in the generator;
the drawing REF axis is grainwise S. Local Y and Z are identified in the
assembled orientation on the part sheets. Use straight, close-grained
hardwood for frame parts, hardwood dowels and dry straight-grained softwood
for boards. Fits are hand-fit; no CNC operations are assumed.

## Four questions for each joint

| Connection | Shared interface and load | Assembly direction | Fit strategy |
| --- | --- | --- | --- |
| Foot to deck | Post shoulder on plywood; 5/8 square x 5/16 tenon | Lower six feet together | 1/32 bottom relief, 1/8 plywood floor |
| Post to plate | Full shoulder, 15/32 x 5/8 head tongue | Lower plate over posts and knee heads | 1/32 bottom relief, 1/8 peg |
| Main tie crossing | Reciprocal 5/16 housings; retained 15/16 webs | Lower tie over shoulders and knee heads | Bearing floor zero gap; crossing peg |
| Principal rafter seats | Full-width horizontal bearing, plumb heel | Slide crown lap into front-open receiver | Seat peg after fit |
| King to tie | 5/8 square through tusk tenon and taper key | Lower king; drive key in X | Fit key to tie soffit |
| Crown and strut laps | Reduced front half, continuous rear material | Common front-entry path | Seat lap cheek and shoulder |
| Knee braces | 45-degree grain, offset square-entering tenons | Foot enters post, beam lowers on head | 1/32 bottom relief |
| Rails | Blind square stub tenons and shoulders | Insert before closing frames | 1/32 bottom relief |
| Roof | Housed purlins and register pin | Lift cassettes normal to the slopes | 1/32 pocket-width clearance; loose socket |

## Material and assembly

Assume dry indoor stock (8-12% MC). White oak tangential movement across
1-1/4 in for a 4-point MC change is approximately 0.019 in. Retain the
1/32 mortise bottom relief and fit concealed cheeks after verifying the stock.
Board gaps are 1/64 in nominal; use low-movement dry softwood and check species
and moisture range before fitting. Do not edge-glue the roof or cladding into
a restrained cross-grain panel. If the measured stock movement requires a
larger gap, reduce board widths evenly without changing the footprint.
The rear closure is sized to the outside post faces; the new width
schedule uses 24 boards. Roof board count reduces from 12 to 10 per panel
so they increase in breadth without expanding the roof plan.

Model verification includes positive-volume interference testing, actual
bearing-area measurements, grain-wise blank checks and sampled insertion
translations. Physical dry fitting and actual moisture measurement remain
shop operations.
