# V7 workshop settings and four-corner traces

Model inches. Use with the dimensioned V7 drawings; the reference datum for each cut below is a separate square line 1.25 inches back from the centerline intersection. For partial seats the trace is a layout line only, not a through crosscut.

Straight stock: square crosscuts, tool tilt 0, miter 0; the datum is the finished end/shoulder. Drill press and chisel blind mortises to the indicated dimensions; straight-sized tenons cut from square stock.

## Material and fit

Assume 8-12% MC. White oak tangential movement estimate at 1.25 in across grain: 0.0188 in; a 1.1844-in board could move 0.0178 in. Use softwood for boards, confirm actual moisture and species movement, retain the drawn gaps, and leave 1/32 hidden depth relief. Keep joint shoulders seated.

## RLF: plumb left end

Blank 1.25 x 1.09375 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.592 | 1 19/32 |
| B | +v, -w | 1.592 | 1 19/32 |
| C | +v, +w | 0.908 | 29/32 |
| D | -v, +w | 0.908 | 29/32 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 32.01 deg on the v faces.
Cut face area: 1.612 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.25 in | 0.00 | 32.01 | fits |
| w-face (the size_v-wide face) | 1.09375 in | 32.01 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 32.01, miter 0.00

## RLF: plumb right end

Blank 1.25 x 1.09375 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 0.908 | 29/32 |
| B | +v, -w | 0.908 | 29/32 |
| C | +v, +w | 1.592 | 1 19/32 |
| D | -v, +w | 1.592 | 1 19/32 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 32.01 deg on the v faces.
Cut face area: 1.612 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.25 in | 0.00 | 32.01 | fits |
| w-face (the size_v-wide face) | 1.09375 in | 32.01 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 32.01, miter 0.00

## RLF: horizontal bearing seat trace ONLY

Blank 1.25 x 1.09375 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 0.375 | 3/8 |
| B | +v, -w | 0.375 | 3/8 |
| C | +v, +w | 2.125 | 2 1/8 |
| D | -v, +w | 2.125 | 2 1/8 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 57.99 deg on the v faces.
Cut face area: 2.580 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.25 in | 0.00 | 57.99 | fits |
| w-face (the size_v-wide face) | 1.09375 in | 57.99 | 0.00 | no: tilt 57.99 exceeds the saw's 45 max |

**Method:** table saw, on the v-face (the size_w-wide face): tilt 0.00, miter 57.99

## RRF: plumb left end

Blank 1.25 x 1.09375 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 0.908 | 29/32 |
| B | +v, -w | 0.908 | 29/32 |
| C | +v, +w | 1.592 | 1 19/32 |
| D | -v, +w | 1.592 | 1 19/32 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 32.01 deg on the v faces.
Cut face area: 1.612 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.25 in | 0.00 | 32.01 | fits |
| w-face (the size_v-wide face) | 1.09375 in | 32.01 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 32.01, miter 0.00

## RRF: plumb right end

Blank 1.25 x 1.09375 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.592 | 1 19/32 |
| B | +v, -w | 1.592 | 1 19/32 |
| C | +v, +w | 0.908 | 29/32 |
| D | -v, +w | 0.908 | 29/32 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 32.01 deg on the v faces.
Cut face area: 1.612 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.25 in | 0.00 | 32.01 | fits |
| w-face (the size_v-wide face) | 1.09375 in | 32.01 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 32.01, miter 0.00

## RRF: horizontal bearing seat trace ONLY

Blank 1.25 x 1.09375 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 0.375 | 3/8 |
| B | +v, -w | 0.375 | 3/8 |
| C | +v, +w | 2.125 | 2 1/8 |
| D | -v, +w | 2.125 | 2 1/8 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 57.99 deg on the v faces.
Cut face area: 2.580 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.25 in | 0.00 | 57.99 | fits |
| w-face (the size_v-wide face) | 1.09375 in | 57.99 | 0.00 | no: tilt 57.99 exceeds the saw's 45 max |

**Method:** table saw, on the v-face (the size_w-wide face): tilt 0.00, miter 57.99

## B1F: post shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.562 | 1 9/16 |
| B | +v, -w | 1.562 | 1 9/16 |
| C | +v, +w | 0.938 | 15/16 |
| D | -v, +w | 0.938 | 15/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 45.00 deg on the v faces.
Cut face area: 0.552 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 45.00 | fits |
| w-face (the size_v-wide face) | 0.625 in | 45.00 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 45.00, miter 0.00 (on the tilt stop: verify the stop with a gauge)

## B1F: beam shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.562 | 1 9/16 |
| B | +v, -w | 1.562 | 1 9/16 |
| C | +v, +w | 0.938 | 15/16 |
| D | -v, +w | 0.938 | 15/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 45.00 deg on the v faces.
Cut face area: 0.552 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 45.00 | fits |
| w-face (the size_v-wide face) | 0.625 in | 45.00 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 45.00, miter 0.00 (on the tilt stop: verify the stop with a gauge)

## B1R: post shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 0.938 | 15/16 |
| B | +v, -w | 0.938 | 15/16 |
| C | +v, +w | 1.562 | 1 9/16 |
| D | -v, +w | 1.562 | 1 9/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 45.00 deg on the v faces.
Cut face area: 0.552 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 45.00 | fits |
| w-face (the size_v-wide face) | 0.625 in | 45.00 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 45.00, miter 0.00 (on the tilt stop: verify the stop with a gauge)

## B1R: beam shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 0.938 | 15/16 |
| B | +v, -w | 0.938 | 15/16 |
| C | +v, +w | 1.562 | 1 9/16 |
| D | -v, +w | 1.562 | 1 9/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 45.00 deg on the v faces.
Cut face area: 0.552 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 45.00 | fits |
| w-face (the size_v-wide face) | 0.625 in | 45.00 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 45.00, miter 0.00 (on the tilt stop: verify the stop with a gauge)

## M1F: post shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.562 | 1 9/16 |
| B | +v, -w | 1.562 | 1 9/16 |
| C | +v, +w | 0.938 | 15/16 |
| D | -v, +w | 0.938 | 15/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 45.00 deg on the v faces.
Cut face area: 0.552 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 45.00 | fits |
| w-face (the size_v-wide face) | 0.625 in | 45.00 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 45.00, miter 0.00 (on the tilt stop: verify the stop with a gauge)

## M1F: tie shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.562 | 1 9/16 |
| B | +v, -w | 1.562 | 1 9/16 |
| C | +v, +w | 0.938 | 15/16 |
| D | -v, +w | 0.938 | 15/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 45.00 deg on the v faces.
Cut face area: 0.552 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 45.00 | fits |
| w-face (the size_v-wide face) | 0.625 in | 45.00 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 45.00, miter 0.00 (on the tilt stop: verify the stop with a gauge)

## M2F: post shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 0.938 | 15/16 |
| B | +v, -w | 0.938 | 15/16 |
| C | +v, +w | 1.562 | 1 9/16 |
| D | -v, +w | 1.562 | 1 9/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 45.00 deg on the v faces.
Cut face area: 0.552 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 45.00 | fits |
| w-face (the size_v-wide face) | 0.625 in | 45.00 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 45.00, miter 0.00 (on the tilt stop: verify the stop with a gauge)

## M2F: tie shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 0.938 | 15/16 |
| B | +v, -w | 0.938 | 15/16 |
| C | +v, +w | 1.562 | 1 9/16 |
| D | -v, +w | 1.562 | 1 9/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 45.00 deg on the v faces.
Cut face area: 0.552 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 45.00 | fits |
| w-face (the size_v-wide face) | 0.625 in | 45.00 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 45.00, miter 0.00 (on the tilt stop: verify the stop with a gauge)

## SLF: king shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.167 | 1 5/32 |
| B | +v, -w | 1.167 | 1 5/32 |
| C | +v, +w | 1.333 | 1 11/32 |
| D | -v, +w | 1.333 | 1 11/32 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 14.95 deg on the v faces.
Cut face area: 0.404 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 14.95 | fits |
| w-face (the size_v-wide face) | 0.625 in | 14.95 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 14.95, miter 0.00

## SLF: rafter underside shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 0.958 | 31/32 |
| B | +v, -w | 0.958 | 31/32 |
| C | +v, +w | 1.542 | 1 17/32 |
| D | -v, +w | 1.542 | 1 17/32 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 43.05 deg on the v faces.
Cut face area: 0.535 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 43.05 | fits |
| w-face (the size_v-wide face) | 0.625 in | 43.05 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 43.05, miter 0.00

## SRF: king shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.333 | 1 11/32 |
| B | +v, -w | 1.333 | 1 11/32 |
| C | +v, +w | 1.167 | 1 5/32 |
| D | -v, +w | 1.167 | 1 5/32 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 14.95 deg on the v faces.
Cut face area: 0.404 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 14.95 | fits |
| w-face (the size_v-wide face) | 0.625 in | 14.95 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 14.95, miter 0.00

## SRF: rafter underside shoulder

Blank 0.625 x 0.625 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.542 | 1 17/32 |
| B | +v, -w | 1.542 | 1 17/32 |
| C | +v, +w | 0.958 | 31/32 |
| D | -v, +w | 0.958 | 31/32 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 43.05 deg on the v faces.
Cut face area: 0.535 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 0.625 in | 0.00 | 43.05 | fits |
| w-face (the size_v-wide face) | 0.625 in | 43.05 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 43.05, miter 0.00

## RBL01: plumb left end

Blank 1.18437 x 0.15625 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.299 | 1 5/16 |
| B | +v, -w | 1.299 | 1 5/16 |
| C | +v, +w | 1.201 | 1 3/16 |
| D | -v, +w | 1.201 | 1 3/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 32.01 deg on the v faces.
Cut face area: 0.218 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.18437 in | 0.00 | 32.01 | fits |
| w-face (the size_v-wide face) | 0.15625 in | 32.01 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 32.01, miter 0.00

## RBL01: plumb right end

Blank 1.18437 x 0.15625 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.201 | 1 3/16 |
| B | +v, -w | 1.201 | 1 3/16 |
| C | +v, +w | 1.299 | 1 5/16 |
| D | -v, +w | 1.299 | 1 5/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 32.01 deg on the v faces.
Cut face area: 0.218 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.18437 in | 0.00 | 32.01 | fits |
| w-face (the size_v-wide face) | 0.15625 in | 32.01 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 32.01, miter 0.00

## RBR01: plumb left end

Blank 1.18437 x 0.15625 in (v x w). The cut normal points at the waste, which lies toward -u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.201 | 1 3/16 |
| B | +v, -w | 1.201 | 1 3/16 |
| C | +v, +w | 1.299 | 1 5/16 |
| D | -v, +w | 1.299 | 1 5/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 32.01 deg on the v faces.
Cut face area: 0.218 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.18437 in | 0.00 | 32.01 | fits |
| w-face (the size_v-wide face) | 0.15625 in | 32.01 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 32.01, miter 0.00

## RBR01: plumb right end

Blank 1.18437 x 0.15625 in (v x w). The cut normal points at the waste, which lies toward +u of the cut. L is measured along each corner edge, toward the cut, from a square datum line on the kept stock 1.25 in from the centerline point. Waste lies beyond the trace.

| Corner | (v, w) side | L, in | Nearest 1/32 |
| --- | --- | --- | --- |
| A | -v, -w | 1.299 | 1 5/16 |
| B | +v, -w | 1.299 | 1 5/16 |
| C | +v, +w | 1.201 | 1 3/16 |
| D | -v, +w | 1.201 | 1 3/16 |

Check: A + C = B + D = 2.500 in.
Trace angle from square: 0.00 deg on the w faces, 32.01 deg on the v faces.
Cut face area: 0.218 sq in.

| Face on the table | Stock height | Blade tilt | Miter | Table saw |
| --- | --- | --- | --- | --- |
| v-face (the size_w-wide face) | 1.18437 in | 0.00 | 32.01 | fits |
| w-face (the size_v-wide face) | 0.15625 in | 32.01 | 0.00 | fits |

**Method:** table saw, on the w-face (the size_v-wide face): tilt 32.01, miter 0.00

## Measured / fit-critical items

Confirm actual kerf, square stock, 15/32 deck panel thickness (nominal 1/2), drill diameter and hand-fit tenons. Do not use unmeasured fence thickness or miter-slot placeholders: this design needs no new jig. Clear end grain around pegs and do not force drive pegs in miniature joints.
