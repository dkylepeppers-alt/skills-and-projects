"""Final document integrity and boundary checks; the actual sheets are visually reviewed too."""
from pathlib import Path
import pymupdf
from itertools import combinations
ROOT=Path(__file__).resolve().parents[1]
report=[];bad=[]
for name,count,w,h in [('nativity-construction-plans-v7.pdf',116,1224,792),('nativity-patterns-v7.pdf',34,792,612)]:
    file=ROOT/name;doc=pymupdf.open(file);assert len(doc)==count;assert len(doc.get_toc())==count
    overflow=[];overlaps=[]
    for i,p in enumerate(doc,1):
        assert abs(p.rect.width-w)<.01 and abs(p.rect.height-h)<.01
        spans=[]
        for block in p.get_text('dict')['blocks']:
            if block['type']!=0:continue
            for line in block['lines']:
                for span in line['spans']:
                    t=span['text'].strip();r=pymupdf.Rect(span['bbox'])
                    if not t:continue
                    if r.x0<0 or r.y0<0 or r.x1>w or r.y1>h:overflow.append((i,t))
                    spans.append((t,r))
        # severe text-on-text intersections are warnings for the visual review; token-level
        # span boxes can overlap for intentional stacked dimension lines or rotated labels.
        for (a,r),(b,s) in combinations(spans,2):
            if not r.intersects(s):continue
            q=r&s;frac=q.get_area()/max(.001,min(r.get_area(),s.get_area()))
            if frac>.32 and a!=b:overlaps.append((i,a,b,round(frac,2)))
    report.append(f'{name}: {len(doc)} pages, {w}x{h} pt; {len(doc.get_toc())} navigation bookmarks; {len(overflow)} text spans outside page.\n')
    bad+=overflow+overlaps
    for x in overlaps:print('Review text intersection:',name,x)
    report.append(f'Potential severe text-box intersections (review visually): {len(overlaps)}\n')
    if overlaps:report+=['  '+str(o)+'\n' for o in overlaps]
assert not bad,bad
(ROOT/'validation'/'pdf_integrity.txt').write_text(''.join(report))
print(''.join(report),flush=True)
