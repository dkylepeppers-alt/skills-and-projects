"""Conventional timber/detail sheets, generated from the current model geometry."""

def install(ns):
    # Reuse canvas, geometry functions and shared coverage lists from the main generator.
    globals().update({k:v for k,v in ns.items() if not k.startswith('__') and k not in globals()})
    return part_sheet

def dim_h(a,b,y,ya,yb,label,font=9.4):
    if b<a:a,b,ya,yb=b,a,yb,ya
    if b-a<.005:return
    for x,anchor in ((a,ya),(b,yb)):
        sg=1 if y>=anchor else -1;ln(x,anchor+sg*1.7,x,y+sg*3,DIM,.43)
    ln(a,y,b,y,DIM,.62)
    for x,sg in ((a,1),(b,-1)):
        if b-a<19:sg=-sg;ln(x+sg*8,y,x,y,DIM,.62)
        C.setFillColor(DIM);pa=C.beginPath();pa.moveTo(x,y);pa.lineTo(x+sg*4,y+1.7);pa.lineTo(x+sg*4,y-1.7);pa.close();C.drawPath(pa,fill=1,stroke=0)
    text((a+b)/2,y+3.2,label,font,False,DIM,'center')

def dim_v(a,b,x,xa,xb,label,font=9.4):
    if b<a:a,b,xa,xb=b,a,xb,xa
    if b-a<.005:return
    for y,anchor in ((a,xa),(b,xb)):
        sg=1 if x>=anchor else -1;ln(anchor+sg*1.7,y,x+sg*3,y,DIM,.43)
    ln(x,a,x,b,DIM,.62)
    for y,sg in ((a,1),(b,-1)):
        if b-a<19:sg=-sg;ln(x,y+sg*8,x,y,DIM,.62)
        C.setFillColor(DIM);pa=C.beginPath();pa.moveTo(x,y);pa.lineTo(x+1.7,y+sg*4);pa.lineTo(x-1.7,y+sg*4);pa.close();C.drawPath(pa,fill=1,stroke=0)
    C.saveState();C.translate(x-3.4,(a+b)/2);C.rotate(90);text(0,0,label,font,False,DIM,'center');C.restoreState()

def body_view(mark,face):
    key=(mark,face)
    if key not in BODIES:
        part=P[mark];_,d,_=loc(mark);BODIES[key]=plans.project(d*part.frame.to_local_coords(part.body),face)
    return BODIES[key]

def points(vw):
    ans=[]
    for x,y,a,b in vw.lines+vw.hidden_lines:
        for p in [(x,y),(a,b)]:
            if not any(abs(p[0]-q[0])<.0004 and abs(p[1]-q[1])<.0004 for q in ans):ans.append(p)
    return ans

def unique(vals,tol=.0005):
    out=[]
    for v in sorted(vals):
        if not out or abs(v-out[-1])>tol:out.append(v)
    return out

def xanchor(vw,x,highest=False):
    opts=[y for a,y in points(vw) if abs(a-x)<.0005]
    return (max(opts) if highest else min(opts)) if opts else vw.box[3 if highest else 1]

def yanchor(vw,y,right=True):
    opts=[x for x,a in points(vw) if abs(a-y)<.0005]
    return (max(opts) if right else min(opts)) if opts else vw.box[2 if right else 0]

def draw_locator(x,y,w,L,lo,hi):
    """Scaled longitudinal locator; arrow from REF to the cut edge or bore-axis center."""
    a=x+30;b=x+w-30;scale=(b-a)/L
    rect(a,y,b-a,7,GREY,None,.6);l=a+lo*scale;r=a+hi*scale
    C.setFillColor(TINT);C.setStrokeColor(DIM);C.setLineWidth(.8)
    if r-l>1:C.rect(l,y,r-l,7,fill=1,stroke=1)
    ln(l,y-4,l,y+11,DIM,.8)
    if r-l>1:ln(r,y-4,r,y+11,DIM,.8)
    text(a,y-10,'REF END',7.4,True,SECOND);text(b,y-10,'FAR END',7.4,True,SECOND,'right')
    if lo>.0005:dim_h(a,l,y+22,y+7,y+7,fmt(lo),9.1)
    else:text(a+7,y+16,'AT REF END',8.2,False,DIM)

def zoom_feature(mark,face,vw,x,y,w,bore=None,dia=None,context='finished',scale=None):
    ctx=view_for(mark,face) if context=='finished' else body_view(mark,face)
    cross=ctx.box[3];lx,ly,hx,hy=vw.box
    s=scale if scale is not None else min(180,118/max(hx-lx,.11),78/max(cross,hy,.11))
    centre=x+w/2;zero=y+44;ox=centre-(lx+hx)/2*s
    fn=lambda p:(ox+p[0]*s,zero+p[1]*s)
    C.saveState();p=C.beginPath();p.rect(centre-77,zero-1,154,87);C.clipPath(p,stroke=0,fill=0)
    path_lines(ctx.hidden,fn,GREY,.36,[2.4,2.6]);path_lines(ctx.visible,fn,GREY,.65);C.restoreState()
    ln(centre-80,zero,centre+80,zero,GREY,.43,[5,2]);text(centre-79,zero-9,'REF FACE',7.2,False,SECOND)
    path_lines(vw.hidden,fn,DIM,.55,[3,2]);path_lines(vw.visible,fn,DIM,1.05)
    text(x+5,y+5,'FACE A / SIDE' if face=='front' else 'FACE B / TOP',8.3,True,INK)
    if bore:
        pa,pb=sorted(bore,key=lambda p:p[0]);qa,qb=plans.to_view(pa,face),plans.to_view(pb,face);a,b=fn(qa),fn(qb)
        ln(*a,*b,DIM,.65,[5,2,1,2])
        for z in (a,b):ln(z[0]-4,z[1],z[0]+4,z[1],DIM,.55);ln(z[0],z[1]-4,z[0],z[1]+4,DIM,.55)
        qlow,qhigh=sorted((qa,qb),key=lambda p:p[1]);al,ah=fn(qlow),fn(qhigh)
        if qlow[1]>.0005:dim_v(zero,al[1],centre-88,centre-80,al[0],fmt(qlow[1]),8.5)
        if qhigh[1]-qlow[1]>.0005:dim_v(al[1],ah[1],centre+83,al[0],ah[0],fmt(qhigh[1]-qlow[1]),8.5)
        if abs(qa[0]-qb[0])>.0005:dim_h(a[0],b[0],y+24,a[1],b[1],fmt(abs(qa[0]-qb[0])),8.5)
        if abs(qa[0]-qb[0])+abs(qa[1]-qb[1])<.0007:
            text(x+5,y+17,'AXIS NORMAL TO FACE',7.6,False,SECOND)
            xx=centre+46;yy=y+142;ln(a[0],a[1],xx-6,yy-1,DIM,.5);text(xx,yy-2,'Ø'+fmt(dia),8.6,False,DIM)
        return
    co=points(vw);xs=unique([lx,hx]+[q[0] for q in co]);ys=unique([ly,hy]+[q[1] for q in co])
    ax,ay=fn((lx,xanchor(vw,lx)));bx,by=fn((hx,xanchor(vw,hx)))
    if hx-lx>.0005:dim_h(ax,bx,y+24,ay,by,fmt(hx-lx),8.8)
    for i,vv in enumerate(xs[1:-1]):
        if i>=4:raise RuntimeError(f'{mark} {face}: too many intermediate horizontal cut edges {xs}')
        a,aa=fn((lx,xanchor(vw,lx,True)));b,bb_=fn((vv,xanchor(vw,vv,True)))
        dim_h(a,b,y+134+i*13,aa,bb_,fmt(vv-lx),8.2)
    ay=fn((lx,ly))[1];by=fn((hx,hy))[1]
    if ly>.0005:dim_v(zero,ay,centre-88,centre-80,fn((yanchor(vw,ly,False),ly))[0],fmt(ly),8.5)
    if hy-ly>.0005:dim_v(ay,by,centre+83,fn((yanchor(vw,ly),ly))[0],fn((yanchor(vw,hy),hy))[0],fmt(hy-ly),8.5)
    for i,vv in enumerate(ys[1:-1]):
        if i>=2:raise RuntimeError(f'{mark} {face}: too many intermediate vertical cut edges {ys}')
        dim_v(ay,fn((lx,vv))[1],centre+100+i*13,fn((yanchor(vw,ly),ly))[0],fn((yanchor(vw,vv),vv))[0],fmt(vv-ly),8.2)

def bore_data(mark,f):
    e=bore_ends(mark,f)
    if e:return e
    a,b,c,d,h,i=bb(local_tool(mark,f));ll=[d-a,h-b,i-c];ax=max(range(3),key=lambda k:ll[k]);p=[(a+d)/2,(b+h)/2,(c+i)/2];q=p.copy();p[ax]=[a,b,c][ax];q[ax]=[d,h,i][ax];return tuple(p),tuple(q)

def feature_card(mark,f,n,x,y,w,h,L):
    rect(x,y,w,h,RULE,white,.6)
    text(x+10,y+h-18,f'D{n:02d}  {f.id}  /  {f.role}',11,True,INK)
    text(x+w-10,y+h-18,'MATES '+f.peer if f.peer else '',9,False,SECOND,'right')
    m=bb(local_tool(mark,f));bore=bore_data(mark,f) if f.role=='BORE' else None
    if bore:
        lo,hi=sorted((bore[0][0],bore[1][0]));length=sqrt(sum((a-b)**2 for a,b in zip(*bore)))
        text(x+w/2,y+h-33,'Ø'+fmt(circle_dia(f))+'   |   DRILL PATH '+fmt(length),9,True,INK,'center')
    else:lo,hi=m[0],m[3]
    draw_locator(x,y+h-83,w,L,max(0,lo),max(0,hi))
    views=[(face,plans.project(local_tool(mark,f),face)) for face in ('front','top')]
    scale=min(180,118/max(.11,*(vw.width for _,vw in views)),78/max(.11,*(max(vw.box[3],view_for(mark,face).box[3]) for face,vw in views)))
    for j,(face,vw) in enumerate(views):
        zoom_feature(mark,face,vw,x+5+j*(w/2),y+4,w/2-10,bore=bore,dia=circle_dia(f) if bore else None,scale=scale)
    DETAIL_COVERAGE.append((mark,f.id))

def sloped_body_edges(mark):
    result=[]
    for face in ('front','top'):
        vw=body_view(mark,face);seen=set()
        for a,b,c,d in vw.lines:
            if abs(a-c)<.0005 or abs(b-d)<.0005:continue
            k=tuple(sorted(((round(a,5),round(b,5)),(round(c,5),round(d,5)))))
            if k in seen:continue
            seen.add(k);result.append((face,((a,b),(c,d))))
    return sorted(result,key=lambda q:(q[0],min(p[0] for p in q[1]),min(p[1] for p in q[1])))

def edge_card(mark,face,edge,n,x,y,w,h,L):
    rect(x,y,w,h,RULE,white,.6);text(x+10,y+h-18,f'E{n:02d}  /  STOCK PROFILE CUT',11,True,INK)
    (a,b),(c,d)=edge;lx,hx=sorted((a,c));ly,hy=sorted((b,d));vw=plans.View2D([list(edge)],[],[(a,b,c,d)],[],(lx,ly,hx,hy))
    draw_locator(x,y+h-83,w,L,max(0,lx),max(0,hx));zoom_feature(mark,face,vw,x+10,y+4,w/2-10,context='body')
    theta=degrees(atan2(abs(d-b),abs(c-a)))
    text(x+w/2+12,y+113,'ANGLE TO GRAIN',9.6,True,DIM);text(x+w/2+12,y+93,f'{theta:.2f}°',18,True,INK)
    para(x+w/2+12,y+71,w/2-26,'Mark the two endpoints of the actual highlighted stock outline and carry the cut across the stock.',9.5,SECOND)

def locator_labels(mark,features,fn,base,face='front'):
    items=[]
    for n,f in features:
        m=bb(local_tool(mark,f));k=2 if face=='front' else 1;p=fn(((m[0]+m[3])/2,(m[k]+m[k+3])/2));items.append((n,p))
    clusters=[]
    for item in items:
        if clusters and item[1][0]-clusters[-1][-1][1][0]<43:clusters[-1].append(item)
        else:clusters.append([item])
    for group in clusters:
        a=group[0][0];b=group[-1][0];xx=sum(p[0] for _,p in group)/len(group);yy=min(p[1] for _,p in group)
        lab=f'D{a:02}' if a==b else f'D{a:02}–D{b:02}'
        ln(xx,yy,xx,base+7,SECOND,.5);C.setFillColor(DIM);C.circle(xx,yy,1.7,fill=1,stroke=0);text(xx,base,lab,9,True,DIM,'center')

def master_spacing(mark,features,fn,s,sy):
    """Direct chain dimensioning for the principal recess positions, with no stacked fan.

    Closely packed features are left to enlarged detail views; all cut locations
    are independently defined from REF on those views.  This is a secondary
    spacing dimension string on the actual timber projection.
    """
    candidates=[]
    for n,f in features:
        if f.role in ('BORE','TENON / TONGUE'):continue
        vw=plans.project(local_tool(mark,f),'front');u=vw.box[0]
        candidates.append((u,xanchor(vw,u),n))
    candidates.sort();chosen=[(0,0,None)]
    for u,vv,n in candidates:
        if (u-chosen[-1][0])*s>=48:chosen.append((u,vv,n))
    if len(chosen)<2:return False
    for (a,b,_),(c,d,n) in zip(chosen,chosen[1:]):
        aa,bb_=fn((a,b));cc,dd=fn((c,d));dim_h(aa,cc,sy-24,bb_,dd,fmt(c-a),9.4)
        text(cc,sy-39,f'D{n:02d}',8.8,True,DIM,'center')
    text(fn((0,0))[0],sy-39,'REF END',8.8,True,DIM)
    text(fn((0,0))[0],sy-58,'CUT SPACING / DIMENSIONED FROM REF IN D DETAILS',8.4,False,SECOND)
    return True

def part_sheet(code,mark,others,title=None,note=''):
    p=P[mark];title=title or mark;bl=loc(mark)[2];L=bl[3]-bl[0];stock=p.stock
    if 'see true' in stock or '45-degree' in stock or 'plumb ends' in stock:stock=stock.split(';')[0]+' x '+fmt(ceil((L+1/8)*8)/8)+' rough'
    heading(code,f'{title}  /  FINISHED TIMBER',f'Marks: {", ".join(others)}  |  Qty {len(others)}  |  {p.material}  |  Stock: {stock}')
    GROUPS.append((code,mark,others,stock,p.material))
    side=view_for(mark,'front');top=view_for(mark,'top');end=view_for(mark,'right')
    s=min(145,1000/max(side.width,top.width,.01),86/max(side.height,top.height,.01));sx=86
    section_label(sx,650,'FACE A  /  SIDE (S × Z)')
    sy=485;f=plot(side,sx,sy,s,True,origin=(0,0));xl=sx;xr=sx+side.width*s;zt=sy+side.height*s
    dim_h(xl,xr,zt+49,f((side.box[0],xanchor(side,side.box[0],True)))[1],f((side.box[2],xanchor(side,side.box[2],True)))[1],fmt(side.width)+' OVERALL',11)
    dim_v(sy,zt,xr+30,f((yanchor(side,side.box[1]),side.box[1]))[0],f((yanchor(side,side.box[3]),side.box[3]))[0],fmt(side.height),10.5)
    raw=body_view(mark,'front');a,b=raw.box[0],raw.box[2]
    if a>.0005 or side.width-b>.0005:
        if a>.0005:dim_h(xl,sx+a*s,zt+24,zt,f((a,xanchor(raw,a,True)))[1],fmt(a),9.7)
        dim_h(sx+a*s,sx+b*s,zt+24,f((a,xanchor(raw,a,True)))[1],f((b,xanchor(raw,b,True)))[1],fmt(b-a)+' BODY',9.7)
        if side.width-b>.0005:dim_h(sx+b*s,xr,zt+24,f((b,xanchor(raw,b,True)))[1],zt,fmt(side.width-b),9.7)
    features=list(enumerate(sorted(p.features,key=lambda q:(bb(local_tool(mark,q))[0]+bb(local_tool(mark,q))[3])/2),1))
    if not master_spacing(mark,features,f,s,sy):
        text(xl,sy-17,'REF END',9.5,True,DIM);ln(xl,sy-2,xl,sy-10,DIM,.7)
    section_label(sx,398,'FACE B  /  TOP (S × Y)')
    ty=269;g=plot(top,sx,ty,s,True,origin=(0,0));tt=ty+top.height*s
    dim_v(ty,tt,xr+30,g((yanchor(top,top.box[1]),top.box[1]))[0],g((yanchor(top,top.box[3]),top.box[3]))[0],fmt(top.height),10.5)
    ln(xl,ty-2,xl,ty-10,DIM,.7);text(xl,ty-18,'REF END',9.5,True,DIM)
    if features:locator_labels(mark,features,g,ty-42,face='top')
    ex=85;ey=92;es=min(100,148/max(end.width,.01),81/max(end.height,.01));plot(end,ex,ey,es,True,origin=(0,0))
    text(ex,ey+end.height*es+12,'RIGHT END',10,True,INK);dim_h(ex,ex+end.width*es,ey-20,ey,ey,fmt(end.width),10)
    dim_v(ey,ey+end.height*es,ex+end.width*es+34,ex+end.width*es,ex+end.width*es,fmt(end.height),10)
    edges=sloped_body_edges(mark);items=[('feature',n,f) for n,f in features]+[('edge',n,e) for n,e in enumerate(edges,1)];pages=ceil(len(items)/4)
    text(315,180,'LAYOUT & ORIENTATION',12,True,DIM)
    para(315,164,820,f'<b>As assembled:</b> {orientation(mark)} The REF end is the extreme finished tip; the low faces in both views are the reference faces. Grain runs lengthwise from REF toward the far end. Use arrow dimensions in the enlarged D (joinery) and E (stock profile) details; gray dashed lines are concealed edges. '+(f'Enlarged details follow on {pages} sheet'+('s.' if pages!=1 else '.') if pages else 'No additional cuts or bores.'),10.8)
    if note:para(315,103,820,note,10,SECOND)
    footer()
    for page in range(pages):
        chunk=items[page*4:page*4+4];child=f'{code}-D{page+1:02}'
        heading(child,f'{title} / ENLARGED CUT DETAILS',f'Parent {code}  |  {mark}  |  Arrowed dimensions from REF or between edges; teal = cut/tongue/axis, gray = surrounding timber')
        for j,(kind,n,item) in enumerate(chunk):
            x=47+(j%2)*570;y=365-(j//2)*290
            if kind=='feature':feature_card(mark,item,n,x,y,557,280,L)
            else:edge_card(mark,*item,n,x,y,557,280,L)
        if len(chunk)<3:
            smallnote(60,300,1095,'HOW TO READ THE DETAILS','The location line gives the distance from the same REF end used on the parent timber drawing. Enlarged views give the actual feature width, height, offsets and bore-axis travel. Face A and Face B identify the same physical surfaces as the parent sheet. A zero offset is omitted when the joint meets the reference face.')
        footer()
