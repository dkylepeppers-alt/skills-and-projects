"""V7 conventional-dimension drawing set, from the proportionally enlarged frame.

The REF corner is a common, grain-wise rectangular stock datum, not an arbitrary
screen projection. Feature extents are extracted from the joint tool solids used
by the model; no dimensions are taken from pixels or from a second hand sketch.
"""
from pathlib import Path
from math import atan2,degrees,ceil
from fractions import Fraction
from functools import lru_cache
import sys, os
from collections import defaultdict
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from build123d import Compound, Pos, Vector, GeomType
from nativity_v7 import *

SKILL=Path(os.environ.get('WOOD_STEREO_SKILL',Path(__file__).resolve().parent))
sys.path.insert(0,str(SKILL/'scripts' if (SKILL/'scripts').is_dir() else SKILL))
from woodstereo import plans, geometry, shop, sheet

OUT=Path(__file__).resolve().parents[1]; B=build(); P=B.parts
WID,HEI=1224,792; C=canvas.Canvas(str(OUT/'nativity-construction-plans-v7.pdf'),pagesize=(WID,HEI),pageCompression=1)
C.setTitle('Nativity barn / V7 enlarged timber frame / construction drawings');C.setAuthor('Workshop design')
INK=HexColor('#182b35'); DIM=HexColor('#136c79'); SECOND=HexColor('#586a73'); GREY=HexColor('#9eabb0'); RULE=HexColor('#d2dce0'); TINT=HexColor('#edf5f5'); BROWN=HexColor('#976235'); GOLD=HexColor('#ac712d'); LIGHT_BG=HexColor('#f7f8f7')
pdfmetrics.registerFont(TTFont('DraftSans','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'))
pdfmetrics.registerFont(TTFont('DraftSans-Bold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFontFamily('DraftSans',normal='DraftSans',bold='DraftSans-Bold',italic='DraftSans',boldItalic='DraftSans-Bold')
FONT='DraftSans'; BOLD='DraftSans-Bold'; MONO='Courier'
PAGE=0; TITLES=[]; GROUPS=[]; LOCAL={}; FEAT={}; PROJ={}; DETAIL_COVERAGE=[]; BODIES={}

def fmt(x):
    if abs(x)<.0005:return '0'
    sign='-' if x<0 else '';x=abs(x);f=Fraction(round(x*64),64)
    if abs(float(f)-x)>0.0002:return sign+f'{x:.3f}'
    w,r=divmod(f.numerator,f.denominator)
    return sign+(f'{w} {r}/{f.denominator}' if w and r else str(w) if not r else f'{r}/{f.denominator}')
def text(x,y,s,size=10,b=False,color=INK,align='left'):
    C.setFont(BOLD if b else FONT,size);C.setFillColor(color)
    {'left':C.drawString,'right':C.drawRightString,'center':C.drawCentredString}[align](x,y,str(s))
def para(x,y,w,s,size=10.5,color=INK,b=False):
    p=Paragraph(s,ParagraphStyle('p',fontName=BOLD if b else FONT,fontSize=size,leading=size*1.28,textColor=color));_,h=p.wrap(w,800);p.drawOn(C,x,y-h);return y-h
def ln(a,b,c,d,color=INK,weight=.7,dash=None):
    C.setStrokeColor(color);C.setLineWidth(weight);C.setDash(dash or []);C.line(a,b,c,d);C.setDash()
def rect(x,y,w,h,color=RULE,fill=None,weight=.7):
    C.setStrokeColor(color);C.setLineWidth(weight);C.setFillColor(fill or white);C.rect(x,y,w,h,fill=int(fill is not None),stroke=1)
def heading(code,title,sub):
    global PAGE;PAGE+=1;TITLES.append((code,title));print(f'{PAGE:02} {code} {title}',flush=True)
    C.bookmarkPage(code);C.addOutlineEntry(f'{code} - {title}',code,level=0,closed=False)
    rect(24,24,WID-48,HEI-48,INK,weight=1)
    rect(24,HEI-91,WID-48,67,INK,INK)
    text(43,HEI-43,'WORKSHOP DRAWING SET  /  1:12 SCALE MODEL',10,True,white)
    text(43,HEI-73,title,25,True,white)
    text(WID-43,HEI-43,code+'  |  REV 7',11,True,white,'right')
    text(WID-43,HEI-71,'ANSI B  /  17 x 11 in  /  DIMENSIONS IN INCHES',9,False,white,'right')
    text(43,HEI-108,sub,11,False,SECOND)
    ln(43,HEI-116,WID-43,HEI-116,RULE,.7)
def footer(note='USE DIMENSIONS - DO NOT SCALE THIS DRAWING'):
    ln(24,57,WID-24,57,INK,.8)
    text(42,42,'NATIVITY BARN  |  TIMBER FRAME  |  NOVEMBER 2026',9,True,INK)
    text(WID/2,42,note,9,True,DIM,'center');text(WID-42,42,f'V7  /  SHEET {PAGE:02d}',10,True,INK,'right')
    C.showPage()
def section_label(x,y,s,sub=None):
    text(x,y,s,13,True,DIM)
    if sub:text(x,y-15,sub,9.5,color=SECOND)
def hdim(x0,x1,y,anchor0,anchor1,label=None):
    if x1<x0:x0,x1,anchor0,anchor1=x1,x0,anchor1,anchor0
    ln(x0,anchor0,x0,y+4,DIM,.45);ln(x1,anchor1,x1,y+4,DIM,.45);ln(x0,y,x1,y,DIM,.65)
    for x,d in [(x0,1),(x1,-1)]:ln(x,y,x+d*5,y+2.3,DIM,.7);ln(x,y,x+d*5,y-2.3,DIM,.7)
    text((x0+x1)/2,y+4,label if label is not None else '',10,True,DIM,'center')
def vdim(y0,y1,x,anchor0,anchor1,label):
    if y1<y0:y0,y1,anchor0,anchor1=y1,y0,anchor1,anchor0
    ln(anchor0,y0,x+4,y0,DIM,.45);ln(anchor1,y1,x+4,y1,DIM,.45);ln(x,y0,x,y1,DIM,.65)
    for y,d in [(y0,1),(y1,-1)]:ln(x,y,x+2.3,y+d*5,DIM,.7);ln(x,y,x-2.3,y+d*5,DIM,.7)
    C.saveState();C.translate(x-4,(y0+y1)/2);C.rotate(90);text(0,0,label,10,True,DIM,'center');C.restoreState()
def path_lines(polys,transform,color=INK,weight=.8,dash=None):
    C.setStrokeColor(color);C.setLineWidth(weight);C.setLineJoin(1);C.setLineCap(1);C.setDash(dash or [])
    for pl in polys:
        if not pl:continue
        pa=C.beginPath();pa.moveTo(*transform(pl[0]));
        for pt in pl[1:]:pa.lineTo(*transform(pt))
        C.drawPath(pa)
    C.setDash()
def plot(view,x,y,scale,hidden=True,origin=None,color=INK,weight=.85):
    ox,oy=view.box[:2] if origin is None else origin
    fn=lambda p:(x+(p[0]-ox)*scale,y+(p[1]-oy)*scale)
    if hidden:path_lines(view.hidden,fn,GREY,.42,[3.2,2.2]);
    path_lines(view.visible,fn,color,weight)
    return fn
def coords(vw):
    xs=[];ys=[]
    for x,y,a,b in vw.lines:xs += [x,a];ys += [y,b]
    for x,y,r,h in vw.circles:xs.append(x);ys.append(y)
    def uniq(arr):
        out=[]
        for a in sorted(arr):
            if not out or abs(a-out[-1])>.0007:out.append(a)
        return out
    return uniq(xs),uniq(ys)
def spread(vals,lo,hi,sep):
    if not vals:return []
    sep=min(sep,(hi-lo)/max(1,len(vals)-1)); out=[]
    for v in vals:out.append(max(lo,v, (out[-1]+sep) if out else lo))
    if out[-1]>hi:
        out[-1]=hi
        for i in range(len(out)-2,-1,-1):out[i]=min(out[i],out[i+1]-sep)
    return out
def ordinate(vw,fn,scale,x,y,band=48,xlabels=True,ylabels=True,xlim=None,ylim=None):
    # Numeric coordinates belong to the common stock datum, not to the bounding box of each feature.
    xs,ys=coords(vw);lx,ly,hx,hy=vw.box; left,bottom=fn((lx,ly));right,top=fn((hx,hy))
    if xlabels:
        xx=[fn((v,ly))[0] for v in xs]; width=max(right-left,150);lo=left-5;hi=max(left+width,right+5)
        if xlim:lo,hi=xlim
        slots=spread(xx,lo,hi,31)
        for i,(v,px,xx2) in enumerate(zip(xs,xx,slots)):
            y2=top+28+(i%2)*21
            ln(px,top,px,top+8,DIM,.38);ln(px,top+8,xx2,y2-4,DIM,.38);ln(xx2,y2-4,xx2,y2-1,DIM,.38)
            text(xx2,y2,fmt(v),9,False,DIM,'center')
        text(left,top+63,'S ORDINATES FROM REF',9,True,DIM)
    if ylabels:
        yy=[fn((lx,v))[1] for v in ys]; lo=bottom-8;hi=max(top+8,bottom+78)
        if ylim:lo,hi=ylim
        slots=spread(yy,lo,hi,12)
        for v,py,ty in zip(ys,yy,slots):
            ln(right,py,right+8,py,DIM,.38);ln(right+8,py,right+20,ty,DIM,.38)
            text(right+23,ty-3,fmt(v),8.8,False,DIM)
    # Reference dot plus grain arrow below the view
    C.setFillColor(DIM);C.circle(left,bottom,2.6,fill=1,stroke=0)
    text(left,bottom-14,'REF 0',9,True,DIM)
    if vw.width>1.7:
        ln(left+55,bottom-13,min(right,left+150),bottom-13,SECOND,.55);ln(min(right,left+150),bottom-13,min(right,left+150)-6,bottom-10,SECOND,.55)
        text(left+60,bottom-25,'GRAIN / S',8.3,False,SECOND)
def bb(shape):
    v=shape.bounding_box();return (v.min.X/U,v.min.Y/U,v.min.Z/U,v.max.X/U,v.max.Y/U,v.max.Z/U)
def loc(mark):
    if mark not in LOCAL:
        p=P[mark];s=p.local();b=bb(s);delta=Pos(*v(tuple(-x for x in b[:3])));LOCAL[mark]=(delta*s,delta,b)
    return LOCAL[mark]
def local_tool(mark,f):
    key=(mark,f.id,f.role)
    if key not in FEAT:
        p=P[mark];_,d,_=loc(mark);tool=f.tool
        if f.role!='TENON / TONGUE':
            q=p.raw.intersect(tool)
            if q is not None and q.solids():tool=Compound(children=list(q.solids())) if len(q.solids())>1 else q.solids()[0]
        FEAT[key]=d*p.frame.to_local_coords(tool)
    return FEAT[key]
def view_for(mark,view):
    key=(mark,view)
    if key not in PROJ:PROJ[key]=plans.project(loc(mark)[0],view)
    return PROJ[key]
def circle_dia(f):
    if f.diameter:return f.diameter
    rr=[e.radius/U for e in f.tool.edges() if e.geom_type==GeomType.CIRCLE]
    return 2*rr[0] if rr else 0
def interval(a,b):return f'{fmt(a)}..{fmt(b)}'
def bore_ends(mark,f):
    """Actual centerline/material intersection, excluding other subtractive tools.
    Keeps oblique seat bores correctly dimensioned rather than calling them normal.
    """
    p=P[mark];cs=[]
    for e in f.tool.edges():
        if e.geom_type==GeomType.CIRCLE:
            z=e.arc_center
            if not any((z-a).length<.0001 for a in cs):cs.append(z)
    if len(cs)!=2:return None
    a,b=cs;direction=(b-a).normalized();L=(b-a).length;e=Edge.make_line(a,b)
    def hits(s):
        q=s.intersect(e);out=[]
        for edge in q or []:
            if not isinstance(edge,Edge):continue
            aa=(edge.start_point()-a).dot(direction);bb_=(edge.end_point()-a).dot(direction)
            if abs(aa-bb_)>.00001:out.append(tuple(sorted((aa,bb_))))
        return out
    ranges=hits(p.raw)
    for cut in p.cuts:
        if cut is f.tool:continue
        for lo,hi in hits(cut):
            new=[]
            for x,y in ranges:
                if hi<=x+1e-6 or lo>=y-1e-6:new.append((x,y));continue
                if lo>x+1e-6:new.append((x,lo))
                if hi<y-1e-6:new.append((hi,y))
            ranges=new
    if not ranges:return None
    lo=min(x for x,y in ranges);hi=max(y for x,y in ranges);minv=loc(mark)[2][:3]
    def local(t):
        r=p.frame.to_local_coords(a+direction*t);return tuple(q/U-o for q,o in zip(r,minv))
    return local(lo),local(hi)
def feat_rows(mark):
    rows=[];p=P[mark]
    for f in p.features:
        t=local_tool(mark,f);m=bb(t);a,b,c,d,e,g=m
        if f.role=='BORE':
            dia=circle_dia(f);ends=bore_ends(mark,f)
            if ends:
                a1,a2=ends;diff=[abs(x-y) for x,y in zip(a1,a2)];axes=[i for i in range(3) if diff[i]>.0001];rng=[interval(x,y) if i in axes else fmt((x+y)/2) for i,(x,y) in enumerate(zip(a1,a2))]
                if len(axes)==1:kind=f'DIA {fmt(dia)}; {"SYZ"[axes[0]]} AXIS'
                else:kind=f'DIA {fmt(dia)}; {"/".join("SYZ"[i] for i in axes)} INCLINED'
            else:
                lens=(d-a,e-b,g-c);ax=max(range(3),key=lambda i:lens[i]);center=((a+d)/2,(b+e)/2,(c+g)/2);rng=[fmt(x) for x in center];rng[ax]=interval(m[ax],m[ax+3]);kind=f'DIA {fmt(dia)}; {"SYZ"[ax]} AXIS'
            length=sqrt(sum((x-y)**2 for x,y in zip(*ends))) if ends else max(d-a,e-b,g-c)
            rows.append((f,kind,*rng,'DRILL PATH '+fmt(length)))
        else:rows.append((f,f.role,interval(a,d),interval(b,e),interval(c,g),'S × Y × Z ENVELOPE: '+ ' × '.join(fmt(q) for q in (d-a,e-b,g-c))))
    return rows
def feature_anchors(mark,view,fn,baseline,lo,hi):
    # IDs on the view map to dimensioned coordinates in the feature schedule.
    items=[]
    for num,f in enumerate(P[mark].features,1):
        t=local_tool(mark,f);b=bb(t);s=tuple((b[i]+b[i+3])/2 for i in range(3));p=plans.to_view(s,view);xp,yp=fn(p)
        items.append((xp,yp,f'{num:02}'))
    items.sort(key=lambda e:e[0]);slots=spread([p[0] for p in items],lo,hi,26)
    for i,((xp,yp,nm),xx) in enumerate(zip(items,slots)):
        y=baseline-(i%2)*17
        ln(xp,yp,xp,y+12,DIM,.35);ln(xp,y+12,xx,y+5,DIM,.35)
        C.setStrokeColor(DIM);C.setFillColor(white);C.circle(xx,y+1,7.3,fill=1,stroke=1);text(xx,y-1.7,nm,8.0,True,DIM,'center')
def short(s,n=40):return s if len(s)<=n else s[:n-1]+'…'
def layout_feature_table(mark,x,y,w):
    section_label(x,y,'JOINT / CUT REGISTER','Matching IDs are printed on the side profile.')
    y-=37; widths=[102,78,74,74];rect(x,y-19,w,19,INK,TINT)
    for j,(label,dx) in enumerate(zip(['FEATURE','S STATION','Y ORD.','Z ORD.'],[6,108,186,260])):text(x+dx,y-13,label,8.5,True,DIM)
    y-=20;rows=feat_rows(mark)
    for num,(f,kind,s,yy,zz,sizes) in enumerate(rows,1):
        h=37
        if y-h<82:raise RuntimeError(f'Feature table overflow: {mark} {len(rows)}')
        rect(x,y-h,w,h,RULE,LIGHT_BG if len(f.id)%2 else white,.45)
        text(x+5,y-11,f'{num:02} / {f.id}',8.4,True,INK);text(x+108,y-11,s,8.5,False,INK);text(x+186,y-11,yy,8.5,False,INK);text(x+260,y-11,zz,8.5,False,INK)
        text(x+5,y-23,kind,8.1,True,DIM);text(x+185,y-23,'MATES '+f.peer if f.peer else '',8,False,SECOND)
        text(x+5,y-32,sizes,7.5,False,SECOND)
        y-=h
    return y
def orientation(mark):
    p=P[mark]
    def direction(vv):
        parts=[];names=[('right','left'),('rear','front'),('up','down')]
        for i,x in enumerate(vv):
            if abs(x)>.08:parts.append(names[i][0 if x>0 else 1])
        return ' / '.join(parts)
    return f'S+ {direction(p.frame.x_dir)}; Y+ {direction(p.frame.y_dir)}; Z+ {direction(p.frame.z_dir)}.'
def part_sheet(code,mark,others,title=None,note=''):
    p=P[mark];title=title or mark;bl=loc(mark)[2];L=bl[3]-bl[0];stock=p.stock
    if 'see true' in stock or '45-degree' in stock or 'plumb ends' in stock:
        stock=stock.split(';')[0]+' x '+fmt(ceil((L+1/8)*8)/8)+' rough'
    heading(code,f'{title}  /  ROUGH & FINISHED LAYOUT',f'Marks: {", ".join(others)}  |  Qty {len(others)}  |  {p.material}  |  Stock: {stock}')
    GROUPS.append((code,mark,others,stock,p.material))
    side=view_for(mark,'front');top=view_for(mark,'top');end=view_for(mark,'right')
    # Both grain-wise faces share a single scale; right-end section is enlarged independently.
    s=min(160,715/max(side.width,top.width,.01),85/max(side.height,top.height,.01));sx=70
    section_label(sx,657,'FACE A  /  SIDE (S × Z)')
    sy=458;f=plot(side,sx,sy,s,True,origin=(0,0));ordinate(side,f,s,sx,sy,xlim=(sx,min(824,sx+max(160,side.width*s))),ylim=(sy-5,sy+max(side.height*s,84)))
    if p.features:feature_anchors(mark,'front',f,sy-46,sx+10,835)
    # Independent dimension line for the entire finished member, not measured from print scale.
    hdim(sx,sx+side.width*s,sy-30,sy,sy,fmt(side.width)+' OVERALL')
    section_label(sx,375,'FACE B  /  TOP (S × Y)')
    ty=212;g=plot(top,sx,ty,s,True,origin=(0,0));ordinate(top,g,s,sx,ty,xlim=(sx,min(824,sx+max(160,top.width*s))),ylim=(ty-5,ty+max(top.height*s,74)))
    # The end view is a separate enlarged representation; only ordinate values are used.
    ex=70;ey=88;es=min(85,126/max(end.width,.01),72/max(end.height,.01));ef=plot(end,ex,ey,es,True,origin=(0,0))
    text(ex,ey+end.height*es+11,'RIGHT END (Y × Z)',9,True,DIM)
    hdim(ex,ex+end.width*es,ey-17,ey,ey,fmt(end.width))
    vdim(ey,ey+end.height*es,ex+end.width*es+28,ex+end.width*es,ex+end.width*es,fmt(end.height))
    a=loc(mark)[2];size=(a[3]-a[0],a[4]-a[1],a[5]-a[2])
    text(285,155,'REFERENCE SYSTEM',11,True,DIM)
    para(285,142,520,f'<b>In assembled orientation:</b> {orientation(mark)} S0 is the extreme finished tip; Y0/Z0 are the low stock faces. Blue values are independent ordinates. Fractional values are exact to 1/64; other values are decimal inches. Dashed edges are hidden. For an inclined bore, start/end values in each column are paired.',10)
    if note:para(285,83,515,note,9.4,SECOND)
    # Sloped edges are fully located by their endpoint ordinates; report their true angles.
    angles=sorted({round(abs(degrees(atan2(y2-y1,x2-x1)))%180,2) for x1,y1,x2,y2 in side.lines if abs(x2-x1)>.03 and abs(y2-y1)>.03})
    y=layout_feature_table(mark,862,645,319)
    if not p.features:y=para(869,590,300,'No mortises or peg bores. Cut to the two dimensioned faces; maintain the section and fit to the adjacent members.',10.5,SECOND)-8
    if angles and y>135:para(869,y-8,300,'Non-square profile edges, angle to +S: '+', '.join(f'{a:.2f}°' for a in angles)+'. Endpoints are dimensioned above.',9.3,SECOND)
    footer()

def assembly_view(groups,view):return plans.project(B.compound(groups),view)
def leader(fn,pt,label,dx,dy,color=DIM):
    x,y=fn(pt);xx=x+dx;yy=y+dy;ln(x,y,xx,yy,color,.6);C.setFillColor(color);C.circle(x,y,2.1,fill=1,stroke=0);text(xx+(4 if dx>=0 else -4),yy+3,label,9.3,True,color,'left' if dx>=0 else 'right')
def smallnote(x,y,w,title,body):
    section_label(x,y,title);return para(x,y-16,w,body,10.5)
from conventional import install as install_conventional
part_sheet=install_conventional(globals())
from conventional import dim_h, dim_v
FRAME={'Base','Frame','Rails','Keys','Pegs'}

heading('A01','KING-POST NATIVITY BARN','V7 enlarged frame  |  1 1/4-inch square main stock  |  unchanged 24 in x 12 in roof plan')
for file,x,y,w,h,label in [('assembled.png',48,302,700,330,'COMPLETE BARN'),('frame.png',760,302,415,330,'FRAME ONLY')]:
    path=OUT/'previews'/file
    if path.exists():C.drawImage(str(path),x,y,w,h,preserveAspectRatio=True,anchor='c',mask='auto')
    else:
        group=None if file=='assembled.png' else FRAME;vs,hs=B.compound(group).project_to_viewport((1200,-1300,1000),look_at=(300,150,180));
        polys=[plans._polyline(e) for e in vs];pts=[p for sub in polys for p in sub];x0=min(p[0] for p in pts);x1=max(p[0] for p in pts);y0=min(p[1] for p in pts);y1=max(p[1] for p in pts);sc=min((w-16)/(x1-x0),(h-16)/(y1-y0));path_lines(polys,lambda p:(x+(w-(x1-x0)*sc)/2+(p[0]-x0)*sc,y+(h-(y1-y0)*sc)/2+(p[1]-y0)*sc),INK,.55)
    text(x+w/2,292,label,12,True,DIM,'center')
ln(43,276,WID-43,276,RULE,.8)
smallnote(48,249,350,'DESIGN BASIS','Asymmetric 7 1/2:12 gable, open main bay, right-hand stall and 1 1/4-inch square posts. Timber sections and vertical elevations increased 25%; roof footprint and post centerlines are fixed. Six feet register in the deck.')
smallnote(426,249,350,'JOINERY','Pegged blind mortise-and-tenon, reciprocal housed crossing, wedged through tusk tenon, pegged open crown laps and strut laps, housed birdsmouth seats and removable housed purlins.')
smallnote(804,249,350,'DRAWING CONVENTIONS','Actual model inches throughout. Blue arrow dimensions locate features from REF or between their edges. Follow D details for each joint and E details for each shaped stock cut. Gray dashed is concealed geometry. Print on 17 x 11 or use dimensions at reduced print size.')
text(48,112,'MODEL SIZE',10,True,DIM);text(48,88,'24 × 12 × '+fmt(height()+BASE_T),23,True,INK)
text(426,112,'FRAME',10,True,DIM);text(426,88,'1 1/4 in square posts',21,True,INK)
text(804,112,'ROOF',10,True,DIM);text(804,88,'2 lift-off panels',21,True,INK)
footer()

heading('A02','FRONT ELEVATION / ROOF GEOMETRY','Full frame at front bent; rear bent follows identical center lines. Z = 0 is deck shoulder.')
front=assembly_view(FRAME,'front');sc=27.5;fx=82;fy=115;ff=plot(front,fx,fy,sc,False,origin=(0,0))
for x in POST_X:
    a,b=ff((x,0));ln(a,b-6,a,ff((x,TIE_TOP+1))[1],GREY,.55,[5,3]);text(a,b-20,fmt(x),10,True,DIM,'center')
for a,b in [(0,POST_X[0]),(POST_X[0],POST_X[1]),(POST_X[1],POST_X[2]),(POST_X[2],24)]:
    hdim(ff((a,0))[0],ff((b,0))[0],fy-42,fy,fy,fmt(b-a))
angle=degrees(atan2(PITCH,1))
hdim(ff((.25,0))[0],ff((23.75,0))[0],654,ff((.25,high(.25)))[1],ff((23.75,high(23.75)))[1],'23 1/2 RAFTER TIP TO TIP')
# Conventional base-to-bearing heights. Separate lanes, not overlapping callout fans.
dim_v(fy,ff((0,PLATE_Z[0]))[1],48,ff((POST_X[0]-HALF,0))[0],ff((POST_X[0]-HALF,PLATE_Z[0]))[0],fmt(PLATE_Z[0]),10)
dim_v(fy,ff((0,TIE_TOP))[1],76,ff((POST_X[0]-HALF,0))[0],ff((POST_X[0]-HALF,TIE_TOP))[0],fmt(TIE_TOP),10)
dim_v(fy,ff((0,STALL_TOP))[1],838,ff((POST_X[-1]+HALF,0))[0],ff((POST_X[-1]+HALF,STALL_TOP))[0],fmt(STALL_TOP),10)
dim_v(fy,ff((0,high(RIDGE)))[1],890,ff((POST_X[-1]+HALF,0))[0],ff((RIDGE,high(RIDGE)))[0],fmt(high(RIDGE)),10)
leader(ff,(RIDGE,high(RIDGE)),'RIDGE X = 8 3/4',60,9)
leader(ff,(4.25,high(4.25)),f'RL / {angle:.2f}°',-35,30);leader(ff,(18.6,high(18.6)),f'RR / {angle:.2f}°',25,35)
for pos,lab,dx,dy in [((1.25,4*F),'P1F',35,15),((16.25,4*F),'P2F',-36,15),((22.75,3*F),'P3F',-35,10),((8.75,11.55*F),'KF',50,5),((7.0,9.45*F),'TF',5,-35),((11.5,11.0*F),'SRF',20,-22),((5.9,11.3*F),'SLF',-35,-27),((3.0,7.75*F),'M1F',-40,-23),((14.5,7.75*F),'M2F',42,-25)]:leader(ff,pos,lab,dx,dy)
smallnote(970,635,203,'PITCH / HEIGHT',f'Rise 7 1/2 per 12 run ({angle:.2f}°). Underside ridge datum = {fmt(APEX)}. Rafter depth = {fmt(RAFTER_D)} normal to pitch. Finished roof ridge above deck = {fmt(height())}.')
smallnote(970,500,203,'BEARING',f'Main seats are at Z {fmt(TIE_TOP)}. The long right rafter also bears on PL3 at Z {fmt(STALL_TOP)}. Full-width bearing is retained.')
smallnote(970,320,203,'BENTS','TF / TR are common. Front-specific roof register bores are present only in RLF and RRF.')
smallnote(970,180,203,'MARKING','Layout X from roof left edge. Main post bays: 15 and 6 1/2 center-to-center.')
footer()

heading('A03','PLAN AND SIDE FRAME',f'Deck, post centers, longitudinal members and bracing. Front faces Y = {fmt(PLATE_ENDS[0])}; rear faces Y = {fmt(PLATE_ENDS[1])}.')
tv=assembly_view(FRAME,'top');sc=28.5;gx=74;gy=291;gg=plot(tv,gx,gy,sc,False,origin=(0,0));
hdim(gg((.5,.5))[0],gg((23.5,.5))[0],gy-21,gy+14,gy+14,'23 BASE');vdim(gg((.5,.5))[1],gg((.5,11.5))[1],gx-22,gx+14,gx+14,'11 BASE')
for y in POST_Y:
    a,b=gg((0,y));ln(a,b,gg((24,y))[0],b,GREY,.45,[4,3]);text(gx+24*sc+7,b-4,fmt(y),9.6,True,DIM)
for x in POST_X:
    a,b=gg((x,0));ln(a,b,a,gg((x,12))[1],GREY,.45,[4,3]);text(a,gy+12*sc+9,fmt(x),10,True,DIM,'center')
for x,lab in zip(POST_X,('PL1','PL2','PL3')):leader(gg,(x,6),lab,35,30)
text(gx,gy+12*sc+25,'TOP PLAN / FRAME ONLY',12,True,DIM)
rv=assembly_view({'Frame','Rails','Base'},'right');rsc=11;rx=865;ry=383;rf=plot(rv,rx,ry,rsc,False,origin=(0,0));text(rx,ry+218,'RIGHT SIDE ELEVATION',12,True,DIM)
hdim(rf((PLATE_ENDS[0],0))[0],rf((PLATE_ENDS[1],0))[0],ry-32,ry,ry,fmt(PLATE_ENDS[1]-PLATE_ENDS[0])+' PLATE');hdim(rf((1.5,0))[0],rf((10.5,0))[0],ry-16,ry,ry,'9 CENTRES')
smallnote(850,300,320,'LONGITUDINAL FRAME',f'PL1 and PL2 stand {fmt(PLATE_Z[0])} above deck to soffit; PL3 stands {fmt(PLATE_Z[2])}. Each 1 1/4 square plate runs from front to rear post face. Braces retain 45-degree axes and square-entering stub tenons.')
smallnote(60,237,365,'ERECTION DATUM',f'Square the six post centers to the base. 9 in front-to-back centers; 15 in left main bay; 6 1/2 in stall bay. Deck: 23 x 11 x {fmt(BASE_T)}. Foot tenons {fmt(2*FOOT)} square, {fmt(FOOT)} long.')
smallnote(456,237,365,'ASSEMBLY ORDER','Build three longitudinal frames without base. Insert side rails and post-foot knee tenons, lower plates onto posts and knee heads. Bring the three frames together along X with the front and rear rails installed.')
smallnote(850,156,320,'PEG JOINTS','Peg each longitudinal frame after dry fit; leave the base until all six feet align. Then drop both ties onto the housed plate crossings and main knee heads.')
footer()

heading('A04','ROOF PLAN / REAR CLADDING','Two removable roof assemblies. Purlins house directly into the principal rafters; one register pin per panel controls longitudinal drift.')
rview=assembly_view({'Roof'},'top');s=29;ox=80;oy=282;rr=plot(rview,ox,oy,s,False,origin=(0,0));
hdim(rr((0,0))[0],rr((24,0))[0],oy-29,oy,oy,'24 ROOF');vdim(oy,oy+12*s,ox-26,ox,ox,'12 ROOF')
for x in (1.9,4.65,7.1,8.75,10.5,13.5,18.75,22.15):
    xx,yy=rr((x,0));ln(xx,yy,xx,oy+12*s,DIM,.65,[4,3]);text(xx,oy+12*s+8,fmt(x),9.5,True,DIM,'center')
text(ox,oy+12*s+26,'PURLIN CENTRE X ORDINATES (WORLD HORIZONTAL)',11,True,DIM)
smallnote(835,632,335,'LEFT PANEL',f'3 purlins, {ROOF_N} roof boards. Purlins {fmt(PURLIN)} square x 12. Each board: {fmt(ROOF_BOARD)} normal thickness, {fmt(BOARD_W)} width, plumb eave and ridge ends.')
smallnote(835,548,335,'RIGHT PANEL',f'4 purlins, {ROOF_N} roof boards. Same cross-section. A single {fmt(PEG_MAIN)} peg in the front rafter under the second purlin locates each panel; {fmt(PEG_MAIN+1/64)} socket clears peg.')
smallnote(835,456,335,'REMOVAL',f'Purlin pocket is {fmt(PURLIN+RELIEF)} wide and {fmt(POCKET)} deep normal to slope. Lift panel normal to roof plane before moving it sideways; do not glue purlins into rafters.')
smallnote(835,365,335,'REAR BOARDS',f'{BACK_N} pieces, {fmt(BACK_T)} thick, {fmt(BACK_W)} wide. Top follows underside of rafters with {fmt(BACK_CLEAR)} clearance; lower end is {fmt(BACK_CLEAR)} above deck. Fit grain vertically; leave 1/64 between boards.')
text(80,227,'BOARD JOINT / TYPICAL (ENLARGED)',12,True,DIM)
for n in range(3):rect(80+n*145,132,142,18,BROWN,HexColor('#e2c49f'),.8)
hdim(80,222,175,150,150,fmt(BOARD_W)+' BOARD');hdim(222,225,161,150,150,'1/64');vdim(132,150,57,80,80,fmt(ROOF_BOARD))
para(550,190,620,f'Fasten boards individually to each purlin with a small central glue spot or fine pins. Do not edge-glue the boards; each narrow board can move across its grain. Keep the ridge and eave cuts plumb ({angle:.2f}° from square to grain).',11)
footer()

heading('A05','BUILD SEQUENCE / FIT STRATEGY','Dry-fit each subassembly before drilling its pegs. Reference marks preserve mirrored-part orientation.')
steps=[('01','Mill and mark','Mill post/plate/tie stock 1 1/4 square. Mark grain, a reference face, square reference edge and S0 end datum. Mill the smaller 5/8 braces and rails in batches; cut tenons last, from the shoulder.'),('02','Longitudinal frames','Lay PL1, PL2, PL3 flat with front and rear posts in line. Insert side rails between posts. Fit long-plane knee foot tenons horizontally into post faces; lower the plate onto all head tenons together.'),('03','Raise the three frames','Insert rear nailers and front stall rails while translating whole longitudinal frames together along X. Dry-fit all three; square the base and lower the six foot tenons into deck mortises.'),('04','Tie crossings and gable knees','Insert the four main knee foot tenons into the post side faces. Lower TF and TR into the 5/16-deep reciprocal housings and onto knee head tenons. Bore crossing pegs before fitting rafters.'),('05','King posts and roof bents','Lower KF/KR through the 5/8 square tie mortises, then fit tapered tusk keys below the tie. Slide each rafter into its crown lap from the front of the bent; its birdsmouth slides over the bearing. Peg crown and drill vertical seat pegs.'),('06','Gable struts, roof, siding','Install the four open-face struts from the front of each bent; peg their shallow laps. Fit purlins into housings, pin or spot-glue roof boards to each group, lift off to finish. Fit back boards individually to nailers.')]
for i,(num,tt,body) in enumerate(steps):
    col=i%2;row=i//2;x=48+col*570;y=641-row*174
    rect(x,y-150,545,154,RULE,LIGHT_BG,.6);rect(x,y-38,43,42,DIM,DIM,.6);text(x+21,y-23,num,19,True,white,'center');text(x+58,y-22,tt,17,True,INK);para(x+17,y-56,510,body,12)
para(48,109,1110,'FIT: Use dry straight-grained stock, ideally 8-12% MC. Bearing shoulders seat at zero allowance; blind mortises are 1/32 deeper than their tenons. At 1 1/4 inch cross-grain a 4% MC swing in flatsawn white oak is approximately 0.019 in. Roof pockets have 1/32 total width clearance and roof/back boards have 1/64 edge gaps. Fit tenons to a sliding hand fit before boring pegs; pare only nonbearing relief faces.',10.8,SECOND)
footer()

heading('A06','SHOP PROCESS / SAW SETTINGS','All timber surfaces are planar or drilled. The profiles are cut through thickness; no CNC or compound tilt setup is required.')
rows=[('Post, plate, tie, rail ends','Square end / shoulder','0°','0°','Crosscut sled or hand saw; pare shoulder.'),('Rafter and roof board ends','Plumb (7 1/2:12 pitch)','0°',f'{angle:.3f}°','Lay broad face flat; flip for mirror end.'),('Rafter birdsmouth seat','Horizontal in world','0°',f'{90-angle:.3f}°','Partial notch: knife trace, hand saw and chisel; do not through-cut.'),('Main and longitudinal knees','45° shoulder','0°','45.00°','Knife both sides; crosscut sled or handsaw; square tenons enter post/beam.'),('Gable struts','Oblique at king and roof','0°','See E details','Bandsaw or hand saw; pare to shoulder lines.'),('King head and waist; tusk key','Profile, planar slopes','0°','See endpoints','Bandsaw profile off reference face; taper wedge by hand.'),('Blind mortises','Straight drill and chisel','N/A','N/A','5/16 chisel for square sockets; drill waste; gauge depth.')]
x=48;y=635;widths=[258,206,92,126,443]
rect(x,y-30,sum(widths),30,DIM,TINT,.7)
for i,h in enumerate(['MEMBER','CUT','BLADE TILT','MITER FROM SQUARE','METHOD']):text(x+7+sum(widths[:i]),y-20,h,10,True,DIM)
y-=30
for row in rows:
    h=53;rect(x,y-h,sum(widths),h,RULE,LIGHT_BG,.5)
    for i,s in enumerate(row):para(x+7+sum(widths[:i]),y-12,widths[i]-13,s,11.1,INK,i==0)
    y-=h
section_label(52,210,'REFERENCE AND FINISHING')
para(52,194,540,'Cut pieces a little long, establish a square grain datum, and transfer the dimensions from the enlarged drawings. For a shaped end, knife the two dimensioned endpoints and carry the line across the other face. A 5/16 chisel fits the square brace and rail sockets. The 5/64 and 1/8 holes are drill-press operations. Check actual bit diameter and blade kerf on scrap.',11)
section_label(625,210,'VERIFY IN YOUR SHOP')
para(625,194,545,'Seat cuts are partial housings; use a guided handsaw and chisel. The model assumes the stock is square, not nominal lumber size. Verify the actual nominal 1/2 deck plywood thickness (15/32 target) and adjust foot mortise depth if necessary, retaining the drawn 1/8 floor.',11)
footer()

heading('A07','LONGITUDINAL FRAME ELEVATIONS','Three individually pegged subassemblies. Each frame is built flat before raising; elevations look toward the left along the X axis.')
for i,(x,z) in enumerate(zip(POST_X,PLATE_Z),1):
    xx=51+(i-1)*378;yy=265;scale=27.2
    names=[f'P{i}F',f'P{i}R',f'PL{i}',f'B{i}F',f'B{i}R']+([f'L{i}-1',f'L{i}-2'] if i in (1,3) else [])
    section_label(xx,636,f'FRAME {i} / PL{i}',f'X centerline {fmt(x)}')
    vvv=plans.project({n:P[n].solid for n in names},'right');f=plot(vvv,xx+5,yy,scale,False,origin=(PLATE_ENDS[0],0))
    for y in POST_Y:
        a,b=f((y,0));ln(a,b-3,a,yy+(z+POST)*scale+19,GREY,.45,[3,2]);text(a,yy-25,fmt(y),9,True,DIM,'center')
    hdim(f((PLATE_ENDS[0],0))[0],f((PLATE_ENDS[1],0))[0],yy-48,yy,yy,fmt(PLATE_ENDS[1]-PLATE_ENDS[0])+' PLATE');hdim(f((1.5,0))[0],f((10.5,0))[0],yy-70,yy-28,yy-28,'9 C-C')
    vdim(yy,yy+z*scale,xx-10,xx+5,xx+5,fmt(z)+' SHOULDER')
    labelx=xx+5+(PLATE_ENDS[1]-PLATE_ENDS[0])*scale+8;text(labelx,yy+(z+POST)*scale-3,fmt(z+POST),9,True,DIM);ln(labelx-8,yy+(z+POST)*scale,labelx-2,yy+(z+POST)*scale,DIM,.6)
    leader(f,(6,z+HALF),f'PL{i}',5,16);leader(f,(1.5,z/2),f'P{i}F',20,15);leader(f,(10.5,z/2),f'P{i}R',-20,15)
    leader(f,(3.6,z-1.3),f'B{i}F',15,-25);leader(f,(8.4,z-1.3),f'B{i}R',-15,-25)
    if i in (1,3):
        leader(f,(5,1.5*F),f'L{i}-1',8,-16);leader(f,(6,2.5*F),f'L{i}-2',8,16)
        for ht in (1.5*F,2.5*F):
            a,b=f((PLATE_ENDS[1],ht));ln(a,b,a+10,b,DIM,.5);text(a+12,b-3,fmt(ht),9,True,DIM)
    smallnote(xx,165,337,'FRAME CONNECTIONS','Post shoulders bear directly on the plate soffit. Peg the 15/32 x 5/8 head tenons; dry-fit both 45-degree knees before lowering the plate. '+('Side rails enter blind 5/16 square sockets.' if i in (1,3) else 'This open interior frame has no side rails.'))
footer()

# ---------------------------------------------------------------- Joint detail drawings: section strips from the actual completed BREP.
def get_feature(mark,code):return next(f for f in P[mark].features if f.id==code)
def cut_actual(mark,f):
    if f.role=='TENON / TONGUE':return f.tool
    q=P[mark].raw.intersect(f.tool)
    if not q or not q.solids():return f.tool
    return Compound(children=list(q.solids())) if len(q.solids())>1 else q.solids()[0]
def joint_card(x,y,w,h,title,mark,code,mating,view,desc):
    f=get_feature(mark,code);tool=cut_actual(mark,f);tb=bb(tool);center=tuple((tb[i]+tb[i+3])/2 for i in range(3));
    rect(x,y,w,h,RULE,LIGHT_BG,.65);text(x+12,y+h-25,title,16,True,INK)
    text(x+12,y+h-43,f'{code}  /  {mark} + {mating}',10,True,DIM)
    # Thin 0.010 inch section through joint centre; crop to a 2.4-inch window. This is not an invented outline.
    d,up,right=plans._axes(view);ax=next(i for i,n in enumerate(d) if n!=0);lo=[center[i]-1.15 for i in range(3)];hi=[center[i]+1.15 for i in range(3)];lo[ax]=center[ax]-.005;hi[ax]=center[ax]+.005
    slab=box(lo[0],hi[0],lo[1],hi[1],lo[2],hi[2]);shapes=[]
    for name,col in [(mark,BROWN),(mating,INK)]:
        q=P[name].solid.intersect(slab)
        if q and q.solids():
            sh=Compound(children=list(q.solids()));shapes.append((plans.project(sh,view),col,sh))
    co=plans.to_view(center,view);sc=min(87,(w*.54-22)/2.3,(h-105)/2.3);xx=x+25;yy=y+29
    origin=(co[0]-1.15,co[1]-1.15)
    # Hatch actual thin-slice section faces, retaining bore and mortise openings.
    for vs,col,sh in shapes:
        for face in sh.faces():
            if face.geom_type!=GeomType.PLANE:continue
            normal=face.normal_at(face.center())
            if normal.dot(Vector(d))<.9999:continue
            path=C.beginPath()
            for wire in [face.outer_wire(),*face.inner_wires()]:
                nn=max(50,int(wire.length/U*45));pts=[]
                for i in range(nn):
                    z=wire.position_at(i/nn);a,b=plans.to_view(tuple(t/U for t in z),view);pts.append((xx+(a-origin[0])*sc,yy+(b-origin[1])*sc))
                path.moveTo(*pts[0]);
                for pt in pts[1:]:path.lineTo(*pt)
                path.close()
            C.saveState();C.clipPath(path,stroke=0,fill=0,fillMode=0)
            fill=HexColor('#e7d5bc') if col==BROWN else HexColor('#e2e9ec');C.setFillColor(fill);C.rect(xx,yy,2.3*sc,2.3*sc,fill=1,stroke=0)
            for a in range(-int(2.3*sc),int(2.3*sc)*2,8):ln(xx+a,yy,xx+a+2.3*sc,yy+2.3*sc,col,.23)
            C.restoreState()
        plot(vs,xx,yy,sc,False,origin=origin,color=col,weight=1.15)
    tv=plans.project(tool,view);tf=plot(tv,xx,yy,sc,False,origin=origin,color=DIM,weight=1.05)
    # The actual shared tool footprint is blue, with overall width and height arrow dimensions.
    a,b,c,e=tv.box;pa=tf((a,b));pb=tf((c,e));
    if tv.width>.03:hdim(pa[0],pb[0],min(y+h-65,pb[1]+14),pb[1],pb[1],fmt(tv.width))
    if tv.height>.03:vdim(pa[1],pb[1],max(x+8,pa[0]-13),pa[0],pa[0],fmt(tv.height))
    text(xx,yy-15,'SECTION THROUGH JOINT',8.6,True,DIM)
    px=x+w*.55;py=y+h-59
    text(px,py,'ACTUAL TOOL / CONNECTION',9,True,DIM)
    # Dimensions from the original BREP tool, not a nominal text-only note.
    tu=P[mark].frame.to_local_coords(tool);fl=bb(tu);dims=(fl[3]-fl[0],fl[4]-fl[1],fl[5]-fl[2]);
    text(px,py-17,'S × Y × Z EXTENTS',8.8,True,SECOND);text(px,py-34,' × '.join(fmt(a) for a in dims),12,True,INK)
    bottom=para(px,py-48,w*.42,desc,10.0)
    second='right' if view=='front' else 'front';sv=plans.project(tool,second);sw,sh=sv.width,sv.height
    ss=min(87,130/max(sw,.03),62/max(sh,.03));sx=px+28;sy=y+33
    text(px,min(bottom-14,y+133),'PERPENDICULAR CUT VIEW',8.8,True,DIM)
    pp=plot(sv,sx,sy,ss,False,color=DIM,weight=1.05)
    hdim(sx,sx+sw*ss,sy+sh*ss+12,sy+sh*ss,sy+sh*ss,fmt(sw))
    vdim(sy,sy+sh*ss,sx-13,sx,sx,fmt(sh))
    text(px,y+15,'BLUE = SHARED CUT   |   HATCHED = TIMBER',7.8,True,SECOND)

joint_pages=[
 ('J01','POST HEAD / FOOT','Load is carried by shoulder contact, not by the peg or hidden mortise bottom.',[
  ('Post head mortise-and-tenon','P1F','H-P1F','PL1','front',f'Post shoulder Z {fmt(PLATE_Z[0])}. Tenon {fmt(.375*F)} across X x {fmt(.5*F)} across Y x {fmt(.375*F)} tall. Mortise depth {fmt(.375*F+RELIEF)}. {fmt(PEG_MAIN)} peg, center {fmt(F*3/16)} above shoulder.'),
  ('Foot tenon into deck','P1F','F-P1F','BASE','front',f'{fmt(2*FOOT)} square x {fmt(FOOT)} tall tenon. Base socket depth {fmt(FOOT+RELIEF)}. Keep the full post shoulder bearing on the deck; 1/32 relief at bottom.')]),
 ('J02','TIE CROSSING / RAFTER BEARING','The main tie crosses each plate in a reciprocal shallow housing. The rafter sits directly on the tie.',[
  ('Reciprocal housed crossing','TF','X-1F','PL1','front',f'Tie and plate are both 1 1/4 square. Both housings are {fmt(FOOT)} deep. Shared bearing Z {fmt(9.25*F)}. Peg DIA {fmt(PEG_MAIN)} through crossing, offset {fmt(5/16*F)} inward and toward rear face.'),
  ('Main rafter birdsmouth','RLF','S-LF','TF','front',f'Seat extends {fmt(POST)} horizontally from the tie end, to Z {fmt(TIE_TOP)}. Plumb heel step takes thrust; vertical {fmt(PEG_MAIN)} peg crosses seat, bored in final position. Full shoulder bearing.')]),
 ('J03','KING POST / CROWN LAP','A through tusk tenon ties the king post to the tie; open crown laps can actually be inserted in the plane of the bent.',[
  ('Keyed king-post tenon','KF','K-F','TF','front',f'{fmt(2*FOOT)} square through tenon; {fmt(1.625*F)} long from king shoulder, protrudes {fmt(.625*F)} below tie. {fmt(F*3/16)}-wide key slot. Seat tapered key against tie soffit.'),
  ('Rafter crown lap','RLF','C-LF','KF','top',f'Full rafter profile tongue extends {fmt(HALF)} horizontally into king head and is {fmt(HALF)} thick across bent. Back half remains continuous. Open on front face; insert along Y. {fmt(PEG_MAIN)} face peg.')]),
 ('J04','STRUTS / KNEE BRACES','The strut laps are open to the front. Knee tenons enter normal to the receiving faces, not on conflicting compound axes.',[
  ('King-post strut foot','SLF','SF-LF','KF','front',f'Strut {fmt(BRACE)} square; reduced lap tongue {fmt(BRACE/2)} thick and {fmt(.375*F)} along grain. Actual profile is oblique at shoulder. Bore {fmt(PEG_SMALL)} through front face.'),
  ('45-degree knee stub tenon','B1F','BF-B1F','P1F','right',f'Brace {fmt(BRACE)} square. {fmt(BRACE/2)} square x {fmt(F*5/16)} long tenon, offset {fmt(F*5/32)} down to remain within grain. Mortise depth {fmt(F*5/16+RELIEF)}. {fmt(PEG_SMALL)} peg.')]),
 ('J05','RAILS / ROOF REGISTER','Small rails have functional blind stub tenons. Each roof cassette lifts from shallow rafter housings.',[
  ('Blind rail end tenon','L1-1','R-L1-1A','P1F','right',f'Rail {fmt(BRACE)} square. {fmt(BRACE/2)} square x {fmt(FOOT)} long centered stub tenon; socket {fmt(FOOT+RELIEF)} deep. Glue only inside socket after dry fit.'),
  ('Purlin housing and register','RLF','U-PUL2F','PUL2','front',f'Pocket width {fmt(PURLIN+RELIEF)} and normal depth {fmt(POCKET)}; purlin {fmt(PURLIN)} square. Register DIA {fmt(PEG_MAIN)}, {fmt(F*3/16)} embedment; loose {fmt(PEG_MAIN+1/64)} socket. Roof lifts off.')]),
 ('J06','LOW PLATE / KNEE HEAD','At stall bearing, the rafter bears directly on the lower plate. Knee heads enter vertically.',[
  ('Low plate birdsmouth','RRF','S-3F','PL3','front',f'Z {fmt(STALL_TOP)} horizontal seat and plumb heel; {fmt(POST)} support width across X. {fmt(PEG_MAIN)} vertical peg {fmt(.30*F)} toward rear to clear post head tenon.'),
  ('Knee head into plate','B1F','BH-B1F','PL1','right',f'{fmt(BRACE/2)} square x {fmt(F*5/16)} tall tenon. Offset {fmt(F*5/32)} along grain; mortise {fmt(F*5/16+RELIEF)} deep. Peg center {fmt(F*5/32)} above shoulder.')]),
 ('J07','THROUGH KEY / STRUT HEAD','The tapered key and strut heads are functional joints with real modeled mating surfaces.',[
  ('Tapered tusk key slot','KF','W-F','WF','front',f'The {fmt(F*3/16)}-wide slot passes through king tenon along X. Key has straight top bearing edge and 1:8 bottom taper; end thicknesses {fmt(F*9/32)} and {fmt(F/8)}. Fit flush to tie soffit.'),
  ('Gable strut head lap','SLF','SH-LF','RLF','front',f'Open front lap projects {fmt(F*.375)} along strut grain with {fmt(BRACE/2)} thickness. Shoulder follows rafter underside plane. Peg DIA {fmt(PEG_SMALL)} after seating shoulders.')])]
for code,title,subtitle,cards in joint_pages:
    heading(code,title,subtitle)
    for i,args in enumerate(cards):joint_card(43+i*573,305,556,345,*args)
    # Lower band provides a shared dimensioning rule rather than hiding individual joint geometry.
    rect(43,75,1138,205,RULE,white,.65)
    if code=='J02' and (OUT/'previews'/'bearing-exploded.png').exists():
        C.drawImage(str(OUT/'previews'/'bearing-exploded.png'),56,80,320,192,preserveAspectRatio=True,anchor='c',mask='auto')
        section_label(405,255,'EXPLODED MAIN BEARING / ACTUAL CAD')
        para(405,238,745,'From bottom up: full post with integral head tenon; 1 1/4-inch plate with upper 5/16 housing; 1 1/4-inch tie with underside 5/16 housing; notched principal rafter. Drill the plate/head peg and crossing peg before installing the rafter. Install the seat peg after the crown lap and seat bear completely.',12)
    else:
        section_label(60,255,'CUT AND FIT')
        para(60,238,530,'Mark REF faces first, transfer the arrow dimensions from the individual enlarged cut details, then mark the connecting cut on all faces. Use a sharp marking knife and square. Mortises are drilled to specified depth and pared square; saw the tenon cheeks before trimming the shoulder. Keep grain running continuously along each projecting tenon.',11)
        section_label(632,255,'CHECK THE SHOULDER BEFORE PEGGING')
        para(632,238,530,'Dry-fit against the bearing face, not the mortise bottom. Confirm socket walls remain intact, then drill and peg the assembled pieces from the indicated face. The drawn pegs are straight-bored, not drawbored: do not introduce an offset on these small sections. Use a sacrificial block to back through drills.',11)
    footer()

# Part details. Front/rear and mirrored variants selected explicitly rather than relying on a silhouette.
for i,mark in enumerate(['P1F','P1R','P2F','P2R','P3F','P3R'],1):part_sheet(f'P{i:02}',mark,[mark],f'{mark}  Post')
part_sheet('P07','PL1',['PL1'],'PL1  Left main plate');part_sheet('P08','PL2',['PL2'],'PL2  Right main plate');part_sheet('P09','PL3',['PL3'],'PL3  Lower stall plate')
part_sheet('P10','TF',['TF','TR'],'T  Main tie',note='Rear mark has the same joint geometry; use suffix R for all joint IDs.')
part_sheet('P11','KF',['KF','KR'],'K  King post',note='Flared crown and waist are saw-profiled. Cut the through tenon and tapered slot before shaping the head.')
for i,mk in enumerate(['RLF','RLR','RRF','RRR'],12):part_sheet(f'P{i:02}',mk,[mk],f'{mk}  Principal rafter',note=f'Normal depth {fmt(RAFTER_D)}. Plumb cuts are {angle:.3f}° from square to grain; seats lie horizontal in assembly.')
part_sheet('P16','SLF',['SLF','SLR'],'SL  Left gable strut',note='Open-lap tongues slide into front-face housings. Grain points from king towards rafter.')
part_sheet('P17','SRF',['SRF','SRR'],'SR  Right gable strut',note='Open-lap tongues slide into front-face housings. Grain points from king towards rafter.')
part_sheet('P18','B1F',['B1F','B2F','B3F'],'B-F  Front longitudinal knee',note='All three front knees have identical local layout. Fit on own mortises.')
part_sheet('P19','B1R',['B1R','B2R','B3R'],'B-R  Rear longitudinal knee',note='Mirrored front knee. Grain and datum remain as shown; do not simply rotate face A.')
part_sheet('P20','M1F',['M1F','M1R'],'M1  Left main-bay knee',note='Front and rear match, with the same 45-degree true profile.')
part_sheet('P21','M2F',['M2F','M2R'],'M2  Right main-bay knee',note='Mirrored left knee. Cut on stated faces.')
part_sheet('P22','L1-1',['L1-1','L1-2','L3-1','L3-2'],'L  Longitudinal rail')
part_sheet('P23','FN2-1',['FN2-1','FN2-2','RN2-1','RN2-2'],'N2  Stall rails')
part_sheet('P24','RN1-1',['RN1-1','RN1-2'],'N1  Main rear nailers')
part_sheet('P25','WF',['WF','WR'],'W  Tusk wedge',note='Upper bearing edge is straight; taper bottom edge. Cut progressively and fit the wedge through the slot.')
part_sheet('P26','PUL1',['PUL1','PUL3','PUR1','PUR3','PUR4'],'PU  Plain housed purlin')
part_sheet('P27','PUL2',['PUL2'],'PUL2  Register purlin')
part_sheet('P28','PUR2',['PUR2'],'PUR2  Register purlin')
part_sheet('P29','RBL01',[f'RBL{i:02}' for i in range(1,ROOF_N+1)],'RBL  Left roof board',note='Plumb cuts each end; see enlarged end-cut details. Space with 1/64 removable shims at assembly.')
part_sheet('P30','RBR01',[f'RBR{i:02}' for i in range(1,ROOF_N+1)],'RBR  Right roof board',note='Plumb cuts each end; see enlarged end-cut details. Space with 1/64 removable shims at assembly.')

# Base has six mortises drawn in plan, with each coordinate and actual section.
heading('P31','BASE / FOOT MORTISES',f'BASE  |  Qty 1  |  {fmt(BASE_T)} plywood  |  23 x 11 finished  |  all coordinates from lower left deck corner')
GROUPS.append(('P31','BASE',['BASE'],P['BASE'].stock,P['BASE'].material))
s=35;bx=90;by=218;bvw=view_for('BASE','top');bf=plot(bvw,bx,by,s,False,origin=(0,0));
hdim(bx,bx+23*s,by-30,by,by,'23');vdim(by,by+11*s,bx-51,bx,bx,'11')
for x in POST_X:
    q=x-.5;px,py=bf((q,0));ln(px,py,px,by+385,DIM,.4,[3,2])
for y in POST_Y:
    r=y-.5;px,py=bf((0,r));ln(px,py,bx+805,py,DIM,.4,[3,2])
stations=[0]+[q-.5 for q in POST_X]+[23]
for a,b in zip(stations,stations[1:]):dim_h(bx+a*s,bx+b*s,by+405,by+385,by+385,fmt(b-a),9.5)
depths=[0]+[q-.5 for q in POST_Y]+[11]
for a,b in zip(depths,depths[1:]):dim_v(by+a*s,by+b*s,bx-23,bx,bx,fmt(b-a),9.5)
for n,f in enumerate(P['BASE'].features):
    m=bb(local_tool('BASE',f));x=(m[0]+m[3])/2;y=(m[1]+m[4])/2;leader(bf,(x,y),f.peer,17,19)
section_label(930,625,'BASE MORTISE DETAIL')
rect(950,500,120,120,INK,None,1.1);r=2*FOOT*104;rect(1010-r/2,560-r/2,r,r,DIM,TINT,1)
hdim(1010-r/2,1010+r/2,604,560+r/2,560+r/2,fmt(2*FOOT));vdim(560-r/2,560+r/2,961,1010-r/2,1010-r/2,fmt(2*FOOT));text(1010,485,'TOP VIEW',9,True,DIM,'center')
bs=160;z0=340;zt=z0+BASE_T*bs;zp=zt-(FOOT+RELIEF)*bs;wp=2*FOOT*bs
rect(941,z0,205,BASE_T*bs,INK,HexColor('#dfc39f'),1);rect(1043.5-wp/2,zp,wp,(FOOT+RELIEF)*bs,DIM,white,1)
vdim(z0,zt,929,941,941,fmt(BASE_T));vdim(zp,zt,1110,1043.5+wp/2,1043.5+wp/2,fmt(FOOT+RELIEF));hdim(1043.5-wp/2,1043.5+wp/2,zt+19,zt,zt,fmt(2*FOOT));text(1042,323,'SECTION THROUGH FOOT',9,True,DIM,'center')
para(930,280,240,f'Each {fmt(2*FOOT)} square pocket is {fmt(FOOT+RELIEF)} deep, leaving a {fmt(BASE_T-FOOT-RELIEF)} floor. Square corners by chisel. All six feet register from the common base datum.',11)
para(90,147,780,f'Base layout uses deck coordinates (X - 1/2 and Y - 1/2 from world datum). Centers: 3/4, 15 3/4 and 22 1/4 along length; 1 and 10 across width. Set mortise edges +/- {fmt(FOOT)} each side of centerline. Mark the six post numbers on underside.',11)
footer()

heading('P32','BACK CLADDING / LENGTH SCHEDULE',f'CB01-CB{BACK_N:02}  |  {fmt(BACK_T)} x {fmt(BACK_W)}  |  one board each  |  1/64 edge clearance at each board joint')
GROUPS.append(('P32','CB01',[f'CB{i:02}' for i in range(1,BACK_N+1)],f'{fmt(BACK_T)} x {fmt(BACK_W)}; cut to schedule','Straight-grain softwood'))
def back_heights(n):
    a=BACK_START+(n-1)*BACK_STEP+BACK_GAP/2;c=BACK_START+n*BACK_STEP-BACK_GAP/2
    return a,c,low(a)-2*BACK_CLEAR,low(c)-2*BACK_CLEAR,low(RIDGE)-2*BACK_CLEAR if a<RIDGE<c else None
for col in range(2):
    x=48+col*565;y=640
    widths=[70,111,111,105,100]
    rect(x,y-29,542,29,DIM,TINT)
    for j,n in enumerate(['MARK','LEFT X','LEFT HEIGHT','RIGHT HEIGHT','RIDGE HEIGHT']):text(x+5+sum(widths[:j]),y-18,n,9,True,DIM)
    y-=29
    for n in range(1+col*(BACK_N//2),1+(col+1)*(BACK_N//2)):
        a,c,h1,h2,ridge=back_heights(n);rec=[f'CB{n:02}',fmt(a),fmt(h1),fmt(h2),fmt(ridge) if ridge else '-'];rect(x,y-22,542,22,RULE,LIGHT_BG if n%2 else white,.5)
        for j,val in enumerate(rec):text(x+5+sum(widths[:j]),y-15,val,10.2,j==0,INK)
        y-=22
section_label(55,251,'BOARD PROFILE / TYPICAL')
poly=[(80,90),(80,197),(140,227),(140,90)];C.setStrokeColor(INK);C.setFillColor(HexColor('#e0c099'));pp=C.beginPath();pp.moveTo(*poly[0]);
for p in poly[1:]:pp.lineTo(*p)
pp.close();C.drawPath(pp,stroke=1,fill=1)
hdim(80,140,76,90,90,fmt(BACK_W));vdim(90,197,65,80,80,'L');vdim(90,227,156,140,140,'R');text(190,193,'7 1/2:12 top bevel',10,True,DIM)
ridgeboard=next((n for n in range(1,BACK_N+1) if back_heights(n)[4] is not None),None)
para(290,235,850,f'Every height is measured from the square lower end of its own board (not from deck). Board starts {fmt(BACK_CLEAR)} above deck; top ends {fmt(BACK_CLEAR)} below theoretical rafter underside. CB{ridgeboard:02} crosses the ridge: cut both slopes to the peak at X 8 3/4. Cut slightly long, then fit the rear closure in place.',11.2)
footer()

heading('P33','PEG AND HARDWOOD KEY SCHEDULE','Round hardwood pegs; straight bores, snug sliding fit before final assembly. Taper keys fit against tie soffit.')
pins=defaultdict(list)
for n,p in P.items():
    if p.group=='Pegs':pins[p.stock].append(n)
y=645;rect(48,y-29,1128,29,DIM,TINT);text(60,y-18,'SIZE (DIAMETER × LENGTH, IN.)',10,True,DIM);text(305,y-18,'QTY',10,True,DIM);text(380,y-18,'LOCATIONS / PEG MARKS',10,True,DIM);y-=29
for k,ns in sorted(pins.items()):
    fields=k.split(' dia x ')
    try:display=f'{fmt(float(fields[0]))} dia x {fmt(float(fields[1]))}'
    except (ValueError,IndexError):display=k
    txt=', '.join(ns);h=max(31,20+ceil(len(txt)/105)*13);rect(48,y-h,1128,h,RULE,LIGHT_BG,.4);text(60,y-19,display,10.5,True,INK);text(305,y-19,len(ns),10.5,True,INK);para(380,y-9,785,txt,10);y-=h
if y<120:raise Exception('Peg list overflow')
para(57,y-20,1110,'The location callouts on part sheets identify the mating bored features. For pegs whose length is determined by a sloped upper face, cut slightly long, insert and pare flush. The modeled seat pegs stop approximately 0.056 in below the nominal high surface and span the seat. Use solid close-grained hardwood.',11)
GROUPS.append(('P33',None,[n for ns in pins.values() for n in ns],'See peg schedule','Hardwood dowel'))
footer()

heading('S01','CUT LIST / MEMBER INDEX','Rough stock sizes are in inches. Finish lengths are controlled by the arrow dimensions on the timber and cut detail sheets.')
for col,chunk in enumerate([GROUPS[:18],GROUPS[18:]]):
    x=48+col*565;y=647;rect(x,y-27,543,27,DIM,TINT);text(x+6,y-17,'SHEET',9,True,DIM);text(x+68,y-17,'MARK / FAMILY',9,True,DIM);text(x+222,y-17,'QTY',9,True,DIM);text(x+267,y-17,'STOCK',9,True,DIM);y-=27
    for code,mark,members,stock,material in chunk:
        label=mark if mark else 'Round pegs';label+=(' + matching' if len(members)>1 and mark else '')
        rect(x,y-25,543,25,RULE,LIGHT_BG if len(members)%2 else white,.4);text(x+6,y-16,code,9.5,True,DIM);text(x+68,y-16,label,9.5,True,INK);text(x+222,y-16,len(members),9.5,False,INK);text(x+267,y-16,short(stock,44),9,False,INK);y-=25
para(50,100,1100,'Mill a little over nominal length on sloped members, establish the square REF datum and work to the arrowed lengths and enlarged profile details. Use part IDs and keep mirrored pairs labeled. Stock widths/depths are finished sizes; for the 5/64 cladding, resaw and plane to thickness. Allow extra stock for fitted pieces.',10.5,SECOND)
footer()
C.save()
print('Completed',PAGE,'sheets',flush=True)

# Explicit coverage test: every solid occurrence is represented in the detail groups or peg schedule.
covered=[s for _,_,members,_,_ in GROUPS for s in members];missing=sorted(set(P)-set(covered));extra=sorted(set(covered)-set(P));dupes=sorted({s for s in covered if covered.count(s)>1})
assert not missing and not extra and not dupes,(missing,extra,dupes)
expected={(mk,f.id) for _,mk,_,_,_ in GROUPS if mk and mk not in ('BASE','CB01') for f in P[mk].features}
assert set(DETAIL_COVERAGE)==expected,(sorted(expected-set(DETAIL_COVERAGE)),sorted(set(DETAIL_COVERAGE)-expected))
(OUT/'validation'/'drawing_coverage.txt').write_text(f'Drawing sheets: {PAGE}\nPart occurrences: {len(covered)}; missing: {missing}; duplicate: {dupes}\nIndividual dimensioned joinery details: {len(DETAIL_COVERAGE)}; missing: 0\nFeature details are derived from finished model joint tool intersections.\n')

