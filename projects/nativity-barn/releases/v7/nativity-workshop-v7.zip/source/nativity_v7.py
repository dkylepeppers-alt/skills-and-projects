"""V7 miniature timber-frame barn. Dimensions in inches; BREP/STEP in mm.

World datum: deck top Z=0, roof plan X=0..24, Y=0..12. Reference axes are
grain-wise; every actual joinery tool is retained for the drawing generator.
The bents are assembled in-plane from the front using pegged open-faced laps;
the longitudinal plates bear directly on post shoulders.
"""
from build123d import *
from dataclasses import dataclass, field
from math import sqrt, hypot, atan2, degrees
from fractions import Fraction
from pathlib import Path
import itertools

U=25.4; W=24.; D=12.; RIDGE=8.75
F=1.25; POST=F; HALF=POST/2; PITCH=.5*F; SEC=sqrt(1+PITCH**2)
# The widened posts require the rafter underside to reach the full inner bearing
# edge, rather than leaving a 1/8-inch strip of unsupported tie. Lower the
# nominal scaled apex by the rise across that extra half-width.
APEX=13.5*F-PITCH*(HALF-.5)
POST_X=(1.25,16.25,22.75); POST_Y=(1.5,10.5)
PLATE_Z=tuple(z*F for z in (8.5,8.5,5.75)); PLATE_ENDS=(POST_Y[0]-HALF,POST_Y[1]+HALF)
TIE_BOTTOM=9.*F; TIE_TOP=10.*F; STALL_TOP=6.75*F; RAFTER_D=.875*F
ROOF_BOARD=.125*F; PURLIN=.375*F; POCKET=.125*F; ROOF_GAP=1/64; BACK_GAP=1/64; RELIEF=1/32
BASE_T=.375*F; BRACE=.5*F; PEG_MAIN=.125; PEG_SMALL=5/64; FOOT=.25*F
ROOF_N=10; ROOF_STEP=D/ROOF_N; BOARD_W=ROOF_STEP-ROOF_GAP
BACK_N=24; BACK_START=POST_X[0]-HALF; BACK_END=POST_X[-1]+HALF
BACK_STEP=(BACK_END-BACK_START)/BACK_N; BACK_W=BACK_STEP-BACK_GAP; BACK_T=F/16
BACK_CLEAR=.125*F
WOOD=(.72,.49,.30); LIGHT=(.86,.66,.43); DARK=(.39,.26,.15); ROOF=(.44,.29,.16); PEG=(.24,.15,.08)

def low(x): return APEX-PITCH*abs(x-RIDGE)
def high(x): return low(x)+RAFTER_D*SEC
def kx(x):return RIDGE+(x-RIDGE)*F
def height():return high(RIDGE)+(PURLIN-POCKET+ROOF_BOARD)*SEC
def stock(*dims):
    def fmt(d):
        q=Fraction(round(d*128),128)
        if abs(float(q)-d)>1e-5:return f'{d:.5f}'.rstrip('0').rstrip('.')
        i,r=divmod(q.numerator,q.denominator)
        return f'{i} {r}/{q.denominator}' if i and r else f'{r}/{q.denominator}' if r else str(i)
    return ' x '.join(fmt(d) for d in dims)
def v(p): return tuple(float(a)*U for a in p)
def box(x0,x1,y0,y1,z0,z1):
    return Pos(*v((x0,y0,z0)))*Box(*v((x1-x0,y1-y0,z1-z0)),align=(Align.MIN,)*3)
def prism(poly, lo, hi, axis='y'):
    pts=[v((a,lo,b) if axis=='y' else (lo,a,b)) for a,b in poly]
    return Solid.extrude(Face(Wire.make_polygon(pts)),v((0,hi-lo,0) if axis=='y' else (hi-lo,0,0)))
def cyl(p, direction, length, diameter):
    return Solid.make_cylinder(diameter*U/2,length*U,Plane(origin=v(p),z_dir=direction))
def norm(p): return tuple(Vector(p).normalized())
def strip(a,b,w,plane_a,plane_b):
    dx,dz=b[0]-a[0],b[1]-a[1]; L=hypot(dx,dz); u=(dx/L,dz/L); n=(-u[1],u[0])
    def pt(sign,plane):
        q=(a[0]+sign*n[0]*w/2,a[1]+sign*n[1]*w/2); p,N=plane
        t=((p[0]-q[0])*N[0]+(p[1]-q[1])*N[1])/(u[0]*N[0]+u[1]*N[1])
        return (q[0]+t*u[0],q[1]+t*u[1])
    return [pt(1,plane_a),pt(1,plane_b),pt(-1,plane_b),pt(-1,plane_a)]

def plane(axis=(1,0,0),up=(0,0,1)):
    return Plane(origin=(0,0,0),x_dir=axis,z_dir=up)

@dataclass
class Feature:
    id:str; description:str; role:str; tool:object; peer:str=''; diameter:float=0; point:tuple|None=None; axis:tuple|None=None

@dataclass
class Part:
    name:str; body:object; frame:object; material:str; color:tuple; group:str; stock:str
    features:list=field(default_factory=list); cuts:list=field(default_factory=list); adds:list=field(default_factory=list); solid:object=None; raw:object=None
    def local(self): return self.frame.to_local_coords(self.solid)

class Barn:
    def __init__(self): self.parts={}; self.joints=[]; self.counter=itertools.count(1)
    def part(self,n,s,frame=None,material='Straight-grain hardwood',color=WOOD,group='Frame',stock=''):
        self.parts[n]=Part(n,s,frame or plane(),material,color,group,stock);return n
    def feature(self,n,id,desc,role,tool,peer='',dia=0,p=None,d=None):
        self.parts[n].features.append(Feature(id,desc,role,tool,peer,dia,p,d))
    def j(self,code,male,female,tool,desc,relief=None):
        self.parts[male].adds.append(tool);self.parts[female].cuts.append(relief if relief is not None else tool)
        self.feature(male,code,desc,'TENON / TONGUE',tool,female)
        self.feature(female,code,desc,'MORTISE / RECESS',relief if relief is not None else tool,male)
        self.joints.append((code,male,female,desc))
    def cut(self,n,code,tool,desc,peer='',role='CUT'):
        self.parts[n].cuts.append(tool);self.feature(n,code,desc,role,tool,peer)
    def pin(self,code,a,b,p,d,L,dia,peg_len=None,peg_start=None,desc='Straight-bored hardwood peg'):
        tool=cyl(p,d,L,dia); name='G-'+code
        self.parts[a].cuts.append(tool); self.parts[b].cuts.append(tool)
        self.feature(a,code,desc,'BORE',tool,b,dia,p,d);self.feature(b,code,desc,'BORE',tool,a,dia,p,d)
        if peg_start is None: peg_start=p
        if peg_len is None: peg_len=L
        # Peg cylinder ends are within the original drill path. Trim to finished surface when needed.
        self.part(name,cyl(peg_start,d,peg_len,dia),plane(norm(d), (0,1,0) if abs(d[1])<.5 else (0,0,1)), 'Hardwood dowel',PEG,'Pegs',f'{dia:.4f} dia x {peg_len:.4f}')
        self.joints.append((code,a,b,desc))
    def finalize(self):
        for p in self.parts.values():
            s=p.body
            for t in p.adds:s=s+t
            p.raw=s
            for t in p.cuts:s=s-t
            s.label=p.name;s.color=Color(*p.color);p.solid=s
        return self
    def solids(self,groups=None): return {n:p.solid for n,p in self.parts.items() if groups is None or p.group in groups}
    def compound(self,groups=None): return Compound(label='Nativity barn V7',children=list(self.solids(groups).values()))

def build():
    b=Barn(); b.part('BASE',box(.5,23.5,.5,11.5,-BASE_T,0),material='15/32 plywood',color=DARK,group='Base',stock=stock(BASE_T,11,23))
    # 3 independent longitudinal frames: square continuous plates on actual posts.
    for i,(x,z) in enumerate(zip(POST_X,PLATE_Z),1):
        pl=f'PL{i}'; b.part(pl,box(x-HALF,x+HALF,*PLATE_ENDS,z,z+POST),plane((0,1,0),(0,0,1)),color=LIGHT,stock=stock(POST,POST,PLATE_ENDS[1]-PLATE_ENDS[0]))
        for side,y in zip('FR',POST_Y):
            p=f'P{i}{side}'; b.part(p,box(x-HALF,x+HALF,y-HALF,y+HALF,0,z),plane((0,0,1),(1,0,0)),stock=stock(POST,POST,z+F*.625))
            foot=box(x-FOOT,x+FOOT,y-FOOT,y+FOOT,-FOOT,0)
            b.j('F-'+p,p,'BASE',foot,'Foot tenon; shoulder on deck',box(x-FOOT,x+FOOT,y-FOOT,y+FOOT,-FOOT-RELIEF,0))
            t=box(x-F*3/16,x+F*3/16,y-FOOT,y+FOOT,z,z+F*.375)
            b.j('H-'+p,p,pl,t,'Post head tenon; plate bears on shoulder',box(x-F*3/16,x+F*3/16,y-FOOT,y+FOOT,z,z+F*.375+RELIEF))
            b.pin('HP-'+p,p,pl,(x-HALF,y,z+F*3/16),(1,0,0),POST,PEG_MAIN)
    # Main front/rear tie crossing onto 1 x 1 plates: reciprocal housed crossing.
    for side,y in zip('FR',POST_Y):
        t='T'+side; k='K'+side; yl,yh=y-HALF,y+HALF
        b.part(t,box(POST_X[0]-HALF,POST_X[1]+HALF,yl,yh,TIE_BOTTOM,TIE_TOP),color=LIGHT,stock=stock(POST,POST,POST_X[1]-POST_X[0]+POST))
        for i,x in enumerate(POST_X[:2],1):
            pl=f'PL{i}'; code=f'X-{i}{side}'
            b.cut(pl,code,box(x-HALF,x+HALF,yl,yh,9.25*F,9.5*F),'Top housing: quarter depth, tie sits on floor',t,'HOUSING')
            b.cut(t,code,box(x-HALF,x+HALF,yl,yh,9*F,9.25*F),'Bottom housing: quarter depth, reciprocal crossing',pl,'HOUSING')
            b.pin('XP-'+str(i)+side,t,pl,(x+F*(.3125 if i==1 else -.3125),y+F*.3125,8.9375*F),(0,0,1),1.0625*F,PEG_MAIN)
        kp=[(kx(x),z*F) for x,z in [(8.125,10),(9.375,10),(9.375,11.125),(9.125,11.5),(9.125,12.125),(9.5,12.625)]]
        kp.extend([(kx(9.5),high(kx(9.5))),(RIDGE,high(RIDGE)),(kx(8),high(kx(8)))])
        kp.extend((kx(x),z*F) for x,z in [(8,12.625),(8.375,12.125),(8.375,11.5),(8.125,11.125)])
        b.part(k,prism(kp,yl,yh),plane((0,0,1),(1,0,0)),color=LIGHT,stock=stock(POST,1.5*F)+'; see true profile')
        ten=box(kx(8.5),kx(9),y-FOOT,y+FOOT,8.375*F,TIE_TOP)
        b.j('K-'+side,k,t,ten,'Through tusk tenon; square through tie')
        # Tapered through key in a longitudinally grained wedge slot. The key upper edge bears against tie soffit.
        keypoly=[(kx(a),z*F) for a,z in [(8.125,9),(9.375,9),(9.375,8.875),(8.125,8.71875)]]
        key=prism(keypoly,y-F*3/32,y+F*3/32); wn='W'+side
        b.part(wn,key,color=PEG,group='Keys',stock=stock(F*3/16,F*9/32,F*1.25))
        b.cut(k,'W-'+side,key,'Through tapered tusk-key slot',wn,'KEY SLOT')
        # Principal rafters: resized pitch, notched seats plus bored vertical peg. Crown laps open at front face.
        for sl,xa,xb,c in [('L',.25,kx(8),POST_X[0]),('R',kx(9.5),23.75,POST_X[1])]:
            r='R'+sl+side; slope=PITCH if sl=='L' else -PITCH
            rf=plane(norm((1,0,slope)),norm((-slope,0,1)))
            b.part(r,prism([(xa,low(xa)),(xb,low(xb)),(xb,high(xb)),(xa,high(xa))],yl,yh),rf,stock=stock(POST,RAFTER_D)+'; see true-length outline')
            seat=box(c-HALF,c+HALF,yl,yh,0,TIE_TOP)
            b.cut(r,'S-'+sl+side,seat,'Birdsmouth on tie: horizontal bearing + plumb heel shoulder',t,'SEAT')
            # 3/32 vertical blind peg crosses seat; bore continues to rafter upper face.
            p=(c,y,9.5625*F); top=high(c); b.pin('SP-'+sl+side,r,t,p,(0,0,1),top-p[2]+.08*F,PEG_MAIN,peg_len=top-p[2]-.045*F)
            if sl=='R':
                x=POST_X[2]; b.cut(r,'S-3'+side,box(x-HALF,x+HALF,yl,yh,0,STALL_TOP),'Birdsmouth on low plate: full bearing + plumb shoulder','PL3','SEAT')
                top=high(x); p=(x,y+.30*F,6.375*F); b.pin('SP-3'+side,r,'PL3',p,(0,0,1),top-p[2]+.08*F,PEG_MAIN,peg_len=top-p[2]-.045*F)
            joint_x=kx(8 if sl=='L' else 9.5); ex=joint_x+(HALF if sl=='L' else -HALF); a,cx=sorted((joint_x,ex))
            lap=prism([(a,low(a)),(cx,low(cx)),(cx,high(cx)),(a,high(a))],yl,y)
            b.j('C-'+sl+side,r,k,lap,'Open-faced, full-depth crown lap; 1/2 thick tongue')
            q=(joint_x+ex)/2; b.pin('CP-'+sl+side,r,k,(q,yl,(high(q)+low(q))/2),(0,1,0),POST,PEG_MAIN)
            # Open-face housed struts. Ends share the receiver surfaces and enter from the front of the bent.
            sign=1 if sl=='L' else -1; a=(RIDGE-sign*.625*F,10.75*F); c=(RIDGE-sign*4,low(RIDGE-sign*4)); A=(a,(1,0)); B=(c,(-sign*PITCH,1)); n='S'+sl+side
            dx,dz=c[0]-a[0],c[1]-a[1]; L=hypot(dx,dz); ux,uz=dx/L,dz/L
            b.part(n,prism(strip(a,c,BRACE,A,B),yl,yl+BRACE),plane(norm((ux,0,uz)),norm((-uz,0,ux))),color=LIGHT,stock=stock(BRACE,BRACE)+'; see true profile')
            A2=((a[0]-ux*.375*F,a[1]-uz*.375*F),(1,0)); B2=((c[0]+ux*.375*F,c[1]+uz*.375*F),B[1])
            ta=prism(strip(a,c,BRACE/2,A2,A),yl,yl+BRACE/2); tb=prism(strip(a,c,BRACE/2,B,B2),yl,yl+BRACE/2)
            b.j('SF-'+sl+side,n,k,ta,'Open-face strut foot lap: 1/4 thickness, 3/8 along grain')
            b.j('SH-'+sl+side,n,r,tb,'Open-face strut head lap: 1/4 thickness, 3/8 along grain')
            b.pin('SFP-'+sl+side,n,k,(a[0]-ux*3/16*F,yl,a[1]-uz*3/16*F),(0,1,0),POST,PEG_SMALL)
            b.pin('SHP-'+sl+side,n,r,(c[0]+ux*3/16*F,yl,c[1]+uz*3/16*F),(0,1,0),POST,PEG_SMALL)
    # Knee braces in side planes: square stub tenons normal to each receiving shoulder.
    # They install foot first, then plates lower vertically onto the head tenons.
    def knee(name,axis,center,a,c,receiver1,receiver2):
        # a=(horizontal,vertical) at post shoulder; c at underside of beam.
        u=norm((c[0]-a[0],0,c[1]-a[1])); dx=c[0]-a[0]; s=1 if dx>0 else -1
        A=(a,(1,0)); B=(c,(0,1)); poly=strip(a,c,BRACE,A,B)
        fr=plane(norm((u[0],0,u[2])) if axis=='y' else norm((0,u[0],u[2])),norm((-u[2],0,u[0])) if axis=='y' else norm((0,-u[2],u[0])))
        b.part(name,prism(poly,center-BRACE/2,center+BRACE/2,axis),fr,color=LIGHT,stock=stock(BRACE,BRACE)+'; 45-degree knee')
        def qbox(h0,h1,z0,z1,th=BRACE/2):
            return box(h0,h1,center-th/2,center+th/2,z0,z1) if axis=='y' else box(center-th/2,center+th/2,h0,h1,z0,z1)
        # Offset both square-entering tongues by half the plunge along the 45-degree grain.
        # A 1/4-square tenon then lies within the 1/2-inch stock and retains at least
        # 0.072 in at the short shoulder in the vertical/horizontal face projection.
        fz=a[1]-F*5/32; hx=c[0]+s*F*5/32
        x0,x1=sorted((a[0],a[0]-s*F*5/16)); ff=qbox(x0,x1,fz-F/8,fz+F/8)
        rx0,rx1=sorted((a[0],a[0]-s*(F*5/16+RELIEF))); rr=qbox(rx0,rx1,fz-F/8,fz+F/8)
        hh=qbox(hx-F/8,hx+F/8,c[1],c[1]+F*5/16); hr=qbox(hx-F/8,hx+F/8,c[1],c[1]+F*5/16+RELIEF)
        b.j('BF-'+name,name,receiver1,ff,'Housed knee foot: square stub tenon into post face',rr)
        b.j('BH-'+name,name,receiver2,hh,'Housed knee head: square stub tenon into beam underside',hr)
        def wp(h,z):return (h,center-BRACE/2,z) if axis=='y' else (center-BRACE/2,h,z)
        d=(0,1,0) if axis=='y' else (1,0,0)
        for suf,rec,h,z in [('F',receiver1,a[0]-s*F*5/32,fz),('H',receiver2,hx,c[1]+F*5/32)]:
            p0=list(wp(h,z)); p0[1 if axis=='y' else 0]-=BRACE/2
            b.pin('BP-'+name+suf,name,rec,tuple(p0),d,POST,PEG_SMALL)
    for i,(x,z) in enumerate(zip(POST_X,PLATE_Z),1):
        for side,y,sgn in [('F',POST_Y[0]+HALF,1),('R',POST_Y[1]-HALF,-1)]:
            knee(f'B{i}{side}','x',x,(y,z-2.25*F),(y+sgn*2.25*F,z),f'P{i}{side}',f'PL{i}')
    for side,y in zip('FR',POST_Y):
        a=POST_X[0]+HALF; c=POST_X[1]-HALF
        knee('M1'+side,'y',y,(a,6.5*F),(a+2.5*F,TIE_BOTTOM),f'P1{side}','T'+side)
        knee('M2'+side,'y',y,(c,6.5*F),(c-2.5*F,TIE_BOTTOM),f'P2{side}','T'+side)
    # Rail joints: 5/8 square body, 5/16 square x 5/16 stub tenons; clean shoulders.
    def rail(n,axis,a,c,center,z,p1,p2):
        def rb(lo,hi,half,h):
            return box(lo,hi,center-half,center+half,z-h,z+h) if axis=='x' else box(center-half,center+half,lo,hi,z-h,z+h)
        b.part(n,rb(a,c,BRACE/2,BRACE/2),plane((1,0,0) if axis=='x' else (0,1,0),(0,0,1)),color=LIGHT,group='Rails',stock=stock(BRACE,BRACE,c-a+2*FOOT))
        for suff,lo,hi,rlo,rhi,rec in [('A',a-FOOT,a,a-FOOT-RELIEF,a,p1),('B',c,c+FOOT,c,c+FOOT+RELIEF,p2)]:
            b.j('R-'+n+suff,n,rec,rb(lo,hi,BRACE/4,BRACE/4),'Blind stub rail tenon',rb(rlo,rhi,BRACE/4,BRACE/4))
    for i in (1,3):
        for q,z in enumerate((1.5,2.5),1):rail(f'L{i}-{q}','y',POST_Y[0]+HALF,POST_Y[1]-HALF,POST_X[i-1],z*F,f'P{i}F',f'P{i}R')
    for side,y,zs,bays in [('F',POST_Y[0],(1.5,2.5),(1,)),('R',POST_Y[1]+BRACE/2,(.75,4.5),(0,1))]:
        for i in bays:
            for q,z in enumerate(zs,1):rail(f'{side}N{i+1}-{q}','x',POST_X[i]+HALF,POST_X[i+1]-HALF,y,z*F,f'P{i+1}{side}',f'P{i+2}{side}')
    # Two removable roof cassettes. Shallow open purlin housings retain 3/4 of rafter depth.
    for sl,xa,xb,xs in [('L',0,RIDGE,(1.9,4.65,7.1)),('R',RIDGE,24,(10.5,13.5,18.75,22.15))]:
        m=PITCH if sl=='L' else -PITCH; u=(1/SEC,m/SEC); n=(-m/SEC,1/SEC)
        def poly(x,w,bottom,top):
            c=(x,high(x));return [(c[0]+du*u[0]+dn*n[0],c[1]+du*u[1]+dn*n[1]) for du,dn in [(-w/2,bottom),(w/2,bottom),(w/2,top),(-w/2,top)]]
        for j,x in enumerate(xs,1):
            pn=f'PU{sl}{j}'; b.part(pn,prism(poly(x,PURLIN,-POCKET,PURLIN-POCKET),0,12),plane((0,1,0),norm((n[0],0,n[1]))),color=DARK,group='Roof',stock=stock(PURLIN,PURLIN,12))
            for side,y in zip('FR',POST_Y):
                r='R'+sl+side
                b.cut(r,'U-'+pn+side,prism(poly(x,PURLIN+RELIEF,-POCKET,.25*F),y-HALF,y+HALF),'Open purlin housing: normal to roof pitch',pn,'HOUSING')
            if j==2:
                y=POST_Y[0]; r='R'+sl+'F'; q=(x-POCKET*n[0],y,high(x)-POCKET*n[1]); start=tuple(a-3/16*F*d for a,d in zip(q,(n[0],0,n[1]))); d=(n[0],0,n[1]); name='RG-'+sl
                b.cut(r,'RG-'+sl,cyl(start,d,3/16*F,PEG_MAIN),'Fixed roof register peg bore',pn,'BORE')
                b.cut(pn,'RG-'+sl,cyl(q,d,7/32*F,PEG_MAIN+1/64),'Loose socket for lift-off register peg',r,'BORE')
                b.part(name,cyl(start,d,3/8*F,PEG_MAIN),plane(d,(0,1,0)),material='Hardwood dowel',color=PEG,group='Pegs',stock=f'{PEG_MAIN} dia x {3/8*F}')
        for j in range(ROOF_N):
            yy=j*ROOF_STEP+ROOF_GAP/2; yz=(j+1)*ROOF_STEP-ROOF_GAP/2
            z=lambda x:high(x)+(PURLIN-POCKET)*SEC
            b.part(f'RB{sl}{j+1:02}',prism([(xa,z(xa)),(xb,z(xb)),(xb,z(xb)+ROOF_BOARD*SEC),(xa,z(xa)+ROOF_BOARD*SEC)],yy,yz),plane(norm((1,0,m)),norm((-m,0,1))),material='Straight-grain softwood',color=ROOF if j%3 else DARK,group='Roof',stock=stock(ROOF_BOARD,BOARD_W)+'; plumb ends')
    # Nonstructural back cladding; pin/nail or small glue spot to the rear rails, not across board edges.
    for j in range(BACK_N):
        a=BACK_START+j*BACK_STEP+BACK_GAP/2; c=BACK_START+(j+1)*BACK_STEP-BACK_GAP/2; xs=[a]+([RIDGE] if a<RIDGE<c else [])+[c]
        poly=[(a,BACK_CLEAR),(c,BACK_CLEAR)]+[(x,low(x)-BACK_CLEAR) for x in reversed(xs)]
        b.part(f'CB{j+1:02}',prism(poly,PLATE_ENDS[1],PLATE_ENDS[1]+BACK_T),plane((0,0,1),(1,0,0)),material='Straight-grain softwood',color=LIGHT if j%3 else WOOD,group='Cladding',stock=stock(BACK_T,BACK_W)+'; length schedule')
    return b.finalize()

def gen_step(): return build().compound()

if __name__=='__main__':
    b=build(); export_step(b.compound(),str(Path(__file__).with_suffix('.step')))
