"""1:1 shop layout patterns, US Letter, actual CAD projection at 72 pt/in.

These are supplementary layout aids. Part details in the ANSI-B plan set
specify all blind cuts, pegs, depth and reference-face orientation.
"""
from pathlib import Path
from fractions import Fraction
from math import ceil
import sys,os
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from build123d import Pos
from nativity_v7 import build,U,v

ROOT=Path(__file__).resolve().parents[1]; SKILL=Path(os.environ.get('WOOD_STEREO_SKILL',Path(__file__).resolve().parent));sys.path.insert(0,str(SKILL/'scripts' if (SKILL/'scripts').is_dir() else SKILL))
from woodstereo import plans,templates
P=build().parts
W,H=792,612; C=canvas.Canvas(str(ROOT/'nativity-patterns-v7.pdf'),pagesize=(W,H));C.setTitle('Nativity barn V7 | full-size layout patterns')
for k,n in [('DS','Regular'),('DSB','Bold')]:pdfmetrics.registerFont(TTFont(k,f'/usr/share/fonts/truetype/liberation/LiberationSans-{n}.ttf'))
INK=HexColor('#172b35'); DIM=HexColor('#136c79'); HIDE=HexColor('#9aa6aa'); RULE=HexColor('#c8d3d7'); PAGE=0
records=[]
def fmt(x):
    f=Fraction(round(x*64),64)
    if abs(float(f)-x)>.0002:return f'{x:.3f}'
    w,r=divmod(f.numerator,f.denominator);return str(w) if not r else f'{w} {r}/{f.denominator}' if w else f'{r}/{f.denominator}'
def text(x,y,s,size=10,b=False,col=INK,align='left'):
    C.setFont('DSB' if b else 'DS',size);C.setFillColor(col);{'left':C.drawString,'center':C.drawCentredString,'right':C.drawRightString}[align](x,y,str(s))
def line(a,b,c,d,col=INK,w=.7,dash=None):C.setStrokeColor(col);C.setLineWidth(w);C.setDash(dash or []);C.line(a,b,c,d);C.setDash()
def paragraph(x,y,w,s):
    p=Paragraph(s,ParagraphStyle('p',fontName='DS',fontSize=10,leading=13,textColor=INK));_,h=p.wrap(w,500);p.drawOn(C,x,y-h)
def cross(x,y):line(x-4,y,x+4,y,DIM,.55);line(x,y-4,x,y+4,DIM,.55)
def page(mark,title,code,L,win,tile,ntiles):
    global PAGE;PAGE+=1
    dest=f'{code}-{tile}';C.bookmarkPage(dest);C.addOutlineEntry(f'{code} - {title} ({tile}/{ntiles})',dest,level=0,closed=False)
    C.setFillColor(INK);C.rect(24,551,744,38,fill=1,stroke=0);text(34,565,title,17,True,white);text(756,565,code+'  |  '+f'TILE {tile}/{ntiles}',10,True,white,'right')
    text(32,535,'ACTUAL SIZE 1:1  |  ALL INCHES  |  US LETTER LANDSCAPE',10,True,DIM)
    text(756,535,'SHEET '+f'{PAGE:02d}',10,True,DIM,'right')
    text(32,517,f'Marks: {mark}    |    Finished grainwise extent {fmt(L)}    |    S station window {fmt(win[0])} to {fmt(win[1])}',9.5)
    line(32,505,760,505,RULE,.7)
def footer(mark,code,win,ntiles):
    # calibration square exact 72 x 72 PDF points, with 2-inch horizontal scale check.
    C.setStrokeColor(INK);C.setLineWidth(.8);C.rect(35,65,72,72,fill=0,stroke=1)
    text(71,145,'1 IN SQUARE',9.5,True,DIM,'center')
    line(133,74,277,74,INK,.8);line(133,69,133,79);line(277,69,277,79);text(205,83,'2 IN CHECK',9,True,DIM,'center')
    paragraph(133,137,620,'Check the square in both axes before using any pattern. Trace solid perimeter and visible surface features only. Dashed edges indicate concealed geometry. Use the dimensioned part sheet '+code+' to locate mortise depth, peg axes and the exact REF face; never treat hidden lines as through-cuts.')
    line(24,44,768,44,RULE,.7);text(32,28,'PRINT ACTUAL SIZE / 100%   —   NO FIT OR SHRINK',10,True,DIM);text(760,28,f'V7  |  {mark}  |  {PAGE:02d}',9,True,INK,'right');C.showPage()
def view(vw,win,x,y,label,overlaps,label_registration=True):
    lo,hi=win;span=hi-lo;scale=72;height=vw.height;xx=x;yy=y
    text(xx,yy+height*scale+13,label,10,True,DIM)
    # Draw an explicit datum/stock baseline with no clipping of true-scale geometry.
    C.saveState();p=C.beginPath();p.rect(xx-.1,yy-.1,span*scale+.2,height*scale+.2);C.clipPath(p,stroke=0,fill=0)
    for paths,col,weight,dash in [(vw.hidden,HIDE,.42,[3,2]),(vw.visible,INK,.82,[])]:
        C.setStrokeColor(col);C.setLineWidth(weight);C.setDash(dash);C.setLineCap(1)
        for poly in paths:
            q=C.beginPath();q.moveTo(xx+(poly[0][0]-lo)*scale,yy+poly[0][1]*scale)
            for a,b in poly[1:]:q.lineTo(xx+(a-lo)*scale,yy+b*scale)
            C.drawPath(q)
        C.setDash()
    C.restoreState()
    line(xx,yy-8,xx+span*scale,yy-8,DIM,.55,[2,2]);cross(xx,yy-8);cross(xx+span*scale,yy-8)
    text(xx,yy-22,'S '+fmt(lo),9,True,DIM);text(xx+span*scale,yy-22,'S '+fmt(hi),9,True,DIM,'right')
    for st,tag in overlaps:
        if lo-1e-5<=st<=hi+1e-5:
            a=xx+(st-lo)*scale;cross(a,yy-8);cross(a,yy+height*scale+4)
            if label_registration:text(a,yy-35,tag,8,True,DIM,'center')

families=[(m,m,f'P{i:02}',f'{m} post') for i,m in enumerate(['P1F','P1R','P2F','P2R','P3F','P3R'],1)]
families += [('PL1','PL1','P07','Left main plate'),('PL2','PL2','P08','Right main plate'),('PL3','PL3','P09','Lower stall plate'),('TF','TF + TR','P10','Main tie'),('KF','KF + KR','P11','King post'),('RLF','RLF','P12','Left front principal'),('RLR','RLR','P13','Left rear principal'),('RRF','RRF','P14','Right front principal'),('RRR','RRR','P15','Right rear principal'),('SLF','SLF + SLR','P16','Left gable strut'),('SRF','SRF + SRR','P17','Right gable strut'),('B1F','B1F / B2F / B3F','P18','Front side knee'),('B1R','B1R / B2R / B3R','P19','Rear side knee'),('M1F','M1F + M1R','P20','Left main knee'),('M2F','M2F + M2R','P21','Right main knee'),('WF','WF + WR','P25','Tusk key')]
vectors=ROOT/'patterns';vectors.mkdir(exist_ok=True)
for rep,marks,code,title in families:
    p=P[rep];local=p.local();bb=local.bounding_box();local=Pos(-bb.min.X,-bb.min.Y,-bb.min.Z)*local;side=plans.project(local,'front');top=plans.project(local,'top');L=local.bounding_box().size.X/U
    # Ten inches fits inside common landscape-letter printer margins. Longer members use fixed 1-in overlap.
    nt=max(1,ceil((L-1)/9));span=(L+nt-1)/nt;wins=[(i*(span-1),i*(span-1)+span) for i in range(nt)]
    assert all(b-a<=10.02 for a,b in wins)
    ov=[(wins[i][1]-d,f'{i+1}{letter}') for i in range(nt-1) for d,letter in zip((.875,.5,.125),'ABC')]
    for i,win in enumerate(wins,1):
        side_y=475-side.height*72;top_y=side_y-53-top.height*72
        assert top_y>=197,(rep,side.height,top.height,top_y)
        page(marks,title,code,L,win,i,len(wins));view(side,win,36,side_y,'FACE A / S × Z — true grain-wise profile',ov,False);view(top,win,36,top_y,'FACE B / S × Y — top face',ov)
        if len(wins)>1:text(133,151,'JOIN TILES: align matching A/B/C registration crosses in the 1-inch overlap.',9,True,DIM)
        else:text(133,151,'REF S0 is left. Mark Y0 / Z0 using the matching part drawing.',9,True,DIM)
        footer(marks,code,win,len(wins));records.append((rep,i,win,L))
    # Full-length editable vector side profile (without concealed edges), in actual inches.
    if rep in ('KF','RLF','RRF','SLF','SRF','B1F','B1R','M1F','M2F','WF'):
        lines=[(a[0],a[1],b[0],b[1]) for poly in side.visible for a,b in zip(poly,poly[1:])]
        cal,lab=templates.calibration_square(0,-2.6,2);lines+=cal
        templates.write_dxf(vectors/f'{rep}-face-A.dxf',lines);templates.write_svg(vectors/f'{rep}-face-A.svg',lines,lab+[(0,side.height+.3,f'{marks} - Face A, REF S0 left - 1:1')])
C.save()
# Page-scale checks on the generated vector PDF. No raster art is placed on any sheet.
import pymupdf
doc=pymupdf.open(ROOT/'nativity-patterns-v7.pdf');assert len(doc)==len(records)
for i,p in enumerate(doc):
    assert abs(p.rect.width-792)<.01 and abs(p.rect.height-612)<.01
    squares=[d for d in p.get_drawings() if abs(d['rect'].width-72)<.02 and abs(d['rect'].height-72)<.02]
    assert squares,(i,'missing true-size calibration square');assert not p.get_images(),(i,'raster on vector pattern')
(ROOT/'validation'/'print_patterns.txt').write_text(f'{len(records)} US Letter 1:1 vector pattern pages; exact 72 x 72 pt calibration squares on each. No raster images.\nLong members overlap 1 inch with three common registered stations.\nEvery pattern is a scaled orthographic projection from the revised BREP model.\n')
print('Pattern sheets:',len(records),flush=True)
