"""CPU orthographic shaded preview from actual build123d BREP tessellation.

This fallback needs no browser or GPU. A depth buffer resolves hidden surfaces;
OCCT hidden-line projection adds visible timber edges to the shaded faces.
"""
import sys,os
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from build123d import Compound, Location
from nativity_v7 import build,box,U,F
ROOT=Path(__file__).resolve().parents[1]
SKILL=Path(os.environ.get('WOOD_STEREO_SKILL',Path(__file__).resolve().parent));sys.path.insert(0,str(SKILL/'scripts' if (SKILL/'scripts').is_dir() else SKILL))
from woodstereo import plans

def unit(a):return a/np.linalg.norm(a)
def raster(parts,path,size=(1800,1200),direction=(1,-1,.72),padding=.09):
    W,H=size;n=unit(np.array(direction,dtype=float));r=unit(np.cross(np.array([0.,0.,1.]),n));up=unit(np.cross(n,r));light=unit(np.array([-.45,-.65,1.2]));allmesh=[];points=[]
    for shape,col in parts:
        vertices,triangles=shape.tessellate(.3,.15)
        vv=np.array([tuple(v) for v in vertices],dtype=float)/U;tri=np.array(triangles,dtype=np.int32)
        pts=np.column_stack([vv@r,vv@up,vv@n]);allmesh.append((pts,vv,tri,col));points.append(pts)
    xyz=np.concatenate(points);mins=xyz[:,:2].min(0);maxs=xyz[:,:2].max(0);ext=maxs-mins;sc=min((W*(1-2*padding))/ext[0],(H*(1-2*padding))/ext[1]);offset=(np.array([W,H])-ext*sc)/2
    buf=np.empty((H,W,3),dtype=np.uint8);buf[:,:,:]=[250,249,247];depth=np.full((H,W),-1e9,dtype=np.float32)
    for pts,vv,tri,col in allmesh:
        xy=(pts[:,:2]-mins)*sc+offset;xy[:,1]=H-xy[:,1]
        for ids in tri:
            a,b,c=xy[ids];va,vb,vc=vv[ids];normal=np.cross(vb-va,vc-va);norm=np.linalg.norm(normal)
            if norm<1e-12:continue
            normal/=norm;fac=.62+.38*max(0,np.dot(normal,light));shade=tuple(int(np.clip(z*255*fac+8,0,255)) for z in col)
            x0=max(0,int(np.floor(min(a[0],b[0],c[0]))));x1=min(W-1,int(np.ceil(max(a[0],b[0],c[0]))));y0=max(0,int(np.floor(min(a[1],b[1],c[1]))));y1=min(H-1,int(np.ceil(max(a[1],b[1],c[1]))));
            if x0>x1 or y0>y1:continue
            denom=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);
            if abs(denom)<1e-10:continue
            xx=np.arange(x0,x1+1,dtype=float)[None,:]+.5;yy=np.arange(y0,y1+1,dtype=float)[:,None]+.5
            wa=((b[1]-c[1])*(xx-c[0])+(c[0]-b[0])*(yy-c[1]))/denom;wb=((c[1]-a[1])*(xx-c[0])+(a[0]-c[0])*(yy-c[1]))/denom;wc=1-wa-wb
            zz=wa*pts[ids[0],2]+wb*pts[ids[1],2]+wc*pts[ids[2],2]
            zb=depth[y0:y1+1,x0:x1+1];mask=(wa>=-.0001)&(wb>=-.0001)&(wc>=-.0001)&(zz>zb)
            zb[mask]=zz[mask];buf[y0:y1+1,x0:x1+1][mask]=shade
    im=Image.fromarray(buf);draw=ImageDraw.Draw(im)
    # HLR uses the same orthographic axis pair as the raster view: x=right, y=up.
    sh=Compound(children=[a for a,_ in parts]);vis,_=sh.project_to_viewport(tuple(n*100000),viewport_up=tuple(up),look_at=(0,0,0))
    for edge in vis:
        pl=plans._polyline(edge);q=[((a-mins[0])*sc+offset[0],H-((b-mins[1])*sc+offset[1])) for a,b in pl];draw.line(q,fill=(83,64,46),width=1)
    im.save(path);print(path,flush=True)

if __name__=='__main__':
    b=build();p=b.parts;preview=ROOT/'previews';preview.mkdir(exist_ok=True)
    raster([(x.solid,x.color) for x in p.values()],preview/'assembled.png')
    raster([(x.solid,x.color) for x in p.values() if x.group in ('Frame','Rails','Base','Keys','Pegs')],preview/'frame.png')
    # Actual clipped pieces, separated in the assembly direction to expose joint tooling.
    crop=box(.25,3.65,.5,4.15,7.05*F,11.05*F);node=[]
    for name,dz in [('P1F',0),('PL1',.80),('TF',1.65),('RLF',2.5)]:
        q=p[name].solid.intersect(crop)
        if q and q.solids():node.append((Compound(children=list(q.solids())).moved(Location((0,0,dz*F*U))),p[name].color))
    raster(node,preview/'bearing-exploded.png',(1200,1000),direction=(1,-1,.63),padding=.13)
