"""Repeatable tilt/miter, corner layout, movement and portable template data."""
from pathlib import Path
import sys,os
from nativity_v7 import *
ROOT=Path(__file__).resolve().parents[1]; SKILL=Path(os.environ.get('WOOD_STEREO_SKILL',Path(__file__).resolve().parent));sys.path.insert(0,str(SKILL/'scripts' if (SKILL/'scripts').is_dir() else SKILL))
from woodstereo import geometry as g, shop, sheet, templates
P=build().parts;sp=ROOT/'source'/'shop-profile.json';profile=shop.load_shop(sp if sp.exists() else SKILL/'assets'/'shop-profile.json')
out=['# V7 workshop settings and four-corner traces','','Model inches. Use with the dimensioned V7 drawings; the reference datum for each cut below is a separate square line 1.25 inches back from the centerline intersection. For partial seats the trace is a layout line only, not a through crosscut.','', 'Straight stock: square crosscuts, tool tilt 0, miter 0; the datum is the finished end/shoulder. Drill press and chisel blind mortises to the indicated dimensions; straight-sized tenons cut from square stock.','','## Material and fit','', f'Assume 8-12% MC. White oak tangential movement estimate at {POST:g} in across grain: {g.movement(POST,.00376,4):.4f} in; a {BOARD_W:.4f}-in board could move {g.movement(BOARD_W,.00376,4):.4f} in. Use softwood for boards, confirm actual moisture and species movement, retain the drawn gaps, and leave 1/32 hidden depth relief. Keep joint shoulders seated.','']
cuts=[]
for n,sign in [('RLF',1),('RRF',-1)]:
    cuts += [(n,'plumb left end',(-1,0,0),POST,RAFTER_D),(n,'plumb right end',(1,0,0),POST,RAFTER_D),(n,'horizontal bearing seat trace ONLY',(0,0,-1),POST,RAFTER_D)]
for n,sgn in [('B1F',1),('B1R',-1)]:cuts += [(n,'post shoulder',(0,-sgn,0),BRACE,BRACE),(n,'beam shoulder',(0,0,1),BRACE,BRACE)]
for n,sgn in [('M1F',1),('M2F',-1)]:cuts += [(n,'post shoulder',(-sgn,0,0),BRACE,BRACE),(n,'tie shoulder',(0,0,1),BRACE,BRACE)]
for n,sgn in [('SLF',-1),('SRF',1)]:cuts += [(n,'king shoulder',(-sgn,0,0),BRACE,BRACE),(n,'rafter underside shoulder',(PITCH*sgn,0,1),BRACE,BRACE)]
for n,sgn in [('RBL01',1),('RBR01',-1)]:cuts += [(n,'plumb left end',(-1,0,0),BOARD_W,ROOF_BOARD),(n,'plumb right end',(1,0,0),BOARD_W,ROOF_BOARD)]
for n,label,normal,ww,hh in cuts:
    p=P[n];fr=g.Frame(tuple(p.frame.x_dir),tuple(p.frame.y_dir),tuple(p.frame.z_dir));out.append(sheet.end_cut_sheet(f'{n}: {label}',normal,fr,ww,hh,profile,1.25))
    if n in ('RLF','RRF','B1F','M1F') and 'trace ONLY' not in label:
        ls=g.layout_lengths(normal,fr,ww,hh,1.25);lines,labels=templates.end_cut_development(ls,ww,hh,g.waste_direction(normal,fr)>0)
        path=ROOT/'patterns';path.mkdir(exist_ok=True);stem=n+'-'+label.replace(' ','-')+'-wrap';templates.write_svg(path/(stem+'.svg'),lines,labels);templates.write_dxf(path/(stem+'.dxf'),lines)
out+=['## Measured / fit-critical items','','Confirm actual kerf, square stock, 15/32 deck panel thickness (nominal 1/2), drill diameter and hand-fit tenons. Do not use unmeasured fence thickness or miter-slot placeholders: this design needs no new jig. Clear end grain around pegs and do not force drive pegs in miniature joints.','']
(ROOT/'shop-data.md').write_text('\n'.join(out));print('Cut layout sheets:',len(cuts),flush=True)
