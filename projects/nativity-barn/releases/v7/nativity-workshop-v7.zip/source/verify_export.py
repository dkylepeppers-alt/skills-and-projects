"""Verify exported CAD against current drawing source and repeated part groups."""
from pathlib import Path
from hashlib import sha256
from importlib.metadata import version
from build123d import import_step, Pos
from nativity_v7 import *

ROOT=Path(__file__).resolve().parents[1]
B=build(); saved=import_step(ROOT/'nativity_v7.step')
exported={s.label:s for s in saved.children}
assert set(exported)==set(B.parts),(set(exported)-set(B.parts),set(B.parts)-set(exported))

def bb(s):
    b=s.bounding_box();return tuple(b.min)+tuple(b.max)
def local(p):
    s=p.local();b=s.bounding_box();return Pos(-b.min.X,-b.min.Y,-b.min.Z)*s
def vol(s):
    return sum(q.volume for q in s.solids()) if s is not None else 0

maxvol=maxbb=0.
for mark,p in B.parts.items():
    a,c=p.solid,exported[mark]
    assert a.is_valid and c.is_valid and len(c.solids())==1
    maxvol=max(maxvol,abs(a.volume-c.volume))
    maxbb=max(maxbb,max(abs(x-y) for x,y in zip(bb(a),bb(c))))
assert maxvol<.01 and maxbb<.0001
groups=[['TF','TR'],['KF','KR'],['SLF','SLR'],['SRF','SRR'],
        ['B1F','B2F','B3F'],['B1R','B2R','B3R'],['M1F','M1R'],['M2F','M2R'],
        ['L1-1','L1-2','L3-1','L3-2'],['FN2-1','FN2-2','RN2-1','RN2-2'],
        ['RN1-1','RN1-2'],['WF','WR'],['PUL1','PUL3','PUR1','PUR3','PUR4'],
        [f'RBL{i:02}' for i in range(1,ROOF_N+1)],
        [f'RBR{i:02}' for i in range(1,ROOF_N+1)]]
maxsym=0
for g in groups:
    a=local(B.parts[g[0]])
    for mark in g[1:]:
        c=local(B.parts[mark]); common=vol(a.intersect(c))
        sym=max(0,a.volume+c.volume-2*common)
        maxsym=max(maxsym,sym)
        assert sym<.01,(g[0],mark,sym)
for n in ('P1F','P1R','P2F','P2R','P3F','P3R'):
    q=B.parts[n].body.bounding_box().size
    assert abs(q.X/U-POST)<1e-8 and abs(q.Y/U-POST)<1e-8,n
e=B.compound().bounding_box().size
assert abs(e.X/U-W)<1e-8 and abs(e.Y/U-D)<1e-8
report=f'build123d {version("build123d")}\nSTEP SHA-256 {sha256((ROOT/"nativity_v7.step").read_bytes()).hexdigest()}\n{len(exported)} labeled single-solid parts matched current source.\nMax volume error {maxvol:.9f} mm^3; max bounding-coordinate error {maxbb:.9f} mm.\n{len(groups)} repeated local-shape groups checked; max symmetric difference {maxsym:.9f} mm^3.\nSix main posts measured 1.25 x 1.25 in; envelope 24 x 12 in.\n'
(ROOT/'validation'/'export_integrity.txt').write_text(report)
print(report)
