"""Independent checks on the labeled assembled solids, with inch-based output."""
from itertools import combinations
from pathlib import Path
import sys
from build123d import Compound, export_step, GeomType, Solid, Vector, Location
from nativity_v7 import *

def run(b):
    parts=list(b.parts.values()); bad=[]; collisions=[]; checked=0; surface=[]
    for p in parts:
        if not p.solid.is_valid or len(p.solid.solids())!=1 or p.solid.volume<=0:bad.append(p.name)
        for f in p.solid.faces():
            if f.geom_type.name not in ('PLANE','CYLINDER'):surface.append((p.name,f.geom_type.name))
    bb=[p.solid.bounding_box() for p in parts]
    for (i,a),(j,c) in combinations(enumerate(parts),2):
        A,B=bb[i],bb[j]
        if any(min(getattr(A.max,d),getattr(B.max,d))-max(getattr(A.min,d),getattr(B.min,d))<1e-5 for d in 'XYZ'):continue
        checked+=1;q=a.solid.intersect(c.solid);vol=sum(x.volume for x in q.solids()) if q is not None else 0
        if vol>1e-4:collisions.append((a.name,c.name,round(vol/U**3,7)))
    dim=b.compound().bounding_box().size
    report=[f'Parts: {len(parts)}; valid single solids: {len(parts)-len(bad)}',f'Envelope inches (X,Y,Z including base): {dim.X/U:.5f}, {dim.Y/U:.5f}, {dim.Z/U:.5f}',f'Candidate pairs tested: {checked}',f'Positive-volume interferences: {len(collisions)}',f'Non-planar/non-cylindrical faces: {len(surface)}',f'Invalid: {bad}',f'Unsupported surface types: {surface}']
    report.extend(str(c) for c in collisions)
    return report, bad, collisions, surface

def workshop_checks(b):
    """Measured intended bearing surfaces; grain-wise stock envelope; sampled insertion paths."""
    from math import pi,sqrt
    p=b.parts; out=[]; failures=[]
    def area(a,c,n,coordinate=None):
        v=Vector(n).normalized();t=.0001*U;area=0
        for face in p[a].solid.faces():
            if face.geom_type!=GeomType.PLANE or face.normal_at(face.center()).dot(v)<.999999:continue
            if coordinate is not None and abs(face.center().dot(v)/U-coordinate)>.00001:continue
            slab=Solid.extrude(face,face.normal_at(face.center())*t);q=slab & p[c].solid
            if q is not None:area+=abs(q.volume)/t/U**2
        return area
    bore=pi*(PEG_MAIN/2)**2
    for a,c,n,z,expected,label in [
        ('P1F','PL1',(0,0,1),PLATE_Z[0],POST**2-(F*.375)*(F*.5),'post shoulder to plate'),
        ('TF','PL1',(0,0,-1),-9.25*F,POST**2-bore,'reciprocal crossing'),
        ('RLF','TF',(0,0,-1),-TIE_TOP,POST**2-2*bore,'main rafter seat (minus seat and flush crossing peg bores)'),
        ('RRF','PL3',(0,0,-1),-STALL_TOP,POST**2-bore,'low rafter seat'),
        ('PUL1','RLF',(PITCH,0,-1),None,PURLIN*POST,'removable purlin floor'),
        ('B1F','P1F',(0,-1,0),-(POST_Y[0]+HALF),BRACE**2*sqrt(2)-(BRACE/2)**2,'knee shoulder')]:
        actual=area(a,c,n,z);err=abs(actual-expected);out.append(f'Bearing {label}: measured {actual:.5f} in^2; intended {expected:.5f}; delta {err:.5f}')
        if err>.0015:failures.append(label)
    # Cross sections of angled members must be contained within the rectangular grain-wise blank.
    for n,part in p.items():
        limits=None
        if n.startswith(('B','M')) and n!='BASE':limits=(BRACE,BRACE)
        elif n.startswith(('SL','SR')):limits=(BRACE,BRACE)
        elif n.startswith(('RL','RR')):limits=(POST,RAFTER_D)
        elif n.startswith('RB'):limits=(BOARD_W,ROOF_BOARD)
        elif n.startswith(('P1','P2','P3','PL','TF','TR')):limits=(POST,POST)
        if limits:
            size=part.local().bounding_box().size;actual=(size.Y/U,size.Z/U)
            if any(a>c+1e-5 for a,c in zip(actual,limits)):failures.append(f'{n} stock envelope {actual} > {limits}')
    out.append('Grain-wise blank cross-section checks: '+('PASS' if not any('stock envelope' in x for x in failures) else 'FAIL'))
    # Check connector movement before pegging. Translation samples are illustrative kinematic checks
    # and not a proof of continuous collision-free motion or a physical dry fit.
    checks=[('PL1',(0,0,1),['P1F','P1R','B1F','B1R']),('TF',(0,0,1),['PL1','PL2','P1F','P2F','M1F','M2F']),('KF',(0,0,1),['TF']),('RLF',(0,-1,0),['TF','KF','PL1','PL2']),('RRF',(0,-1,0),['TF','KF','PL2','PL3']),('SLF',(0,-1,0),['KF','RLF']),('SRF',(0,-1,0),['KF','RRF'])]
    for n,axis,receivers in checks:
        maxvol=0
        for s in (.75,.375,.125,.03125):
            moved=p[n].solid.moved(Location(tuple(s*a*U for a in axis)))
            for r in receivers:
                q=moved.intersect(p[r].solid);vol=sum(k.volume for k in q.solids())/U**3 if q is not None else 0
                maxvol=max(maxvol,vol)
        out.append(f'Insertion {n}: 4 samples, max intersection {maxvol:.6f} in^3')
        if maxvol>1e-6:failures.append(f'{n} insertion path')
    return out,failures

if __name__=='__main__':
    b=build(); print('Model built',len(b.parts),flush=True);report,bad,collisions,surface=run(b)
    extra,failures=workshop_checks(b);report+=extra+[f'Workshop check failures: {failures}']
    print('\n'.join(report),flush=True)
    Path(__file__).resolve().parents[1].joinpath('validation','solid_geometry.txt').write_text('\n'.join(report)+'\n')
    assert not bad and not collisions and not surface and not failures
    export_step(b.compound(),str(Path(__file__).resolve().parents[1]/'nativity_v7.step'))
    export_step(b.compound({'Frame','Rails','Base','Keys','Pegs'}),str(Path(__file__).resolve().parents[1]/'previews'/'frame.step'))
