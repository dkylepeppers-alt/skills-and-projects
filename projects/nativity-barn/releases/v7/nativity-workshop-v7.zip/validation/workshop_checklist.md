# V7 workshop verification

- PASS: assembly envelope 24 x 12 x 19.10820 inches; the six principal posts
  measure exactly 1.25 x 1.25 inches in section.
- PASS: all 145 parts are individually valid single solids; 427 candidate
  intersections tested, none with positive volume above the stated threshold.
  All faces are planar or cylindrical.
- PASS: six representative intended bearing interfaces compared to calculated
  areas, including the full-width main and stall rafter seats.
- PASS: grain-wise section envelopes for principal, secondary and board stock.
- PASS: seven representative connector insertion directions at four sampled
  translations each with zero intersection against their listed receivers.
  This is a sampled check, not proof of continuous motion or physical assembly.
- PASS: STEP re-import matched 145 source solids in shape volume and bounds;
  15 repeated-part groups were compared using normalized local geometry.
- PASS: 116 construction sheets, 34 Letter 1:1 patterns, complete PDF
  bookmarks; no page/text-boundary or severe text intersection defects.
  Pages rendered for visual layout review; selected critical views inspected
  individually. The 189 individually identified representative joint details
  and all 145 occurrences are covered by corresponding sheets or schedules.
- PASS: all 22 selected planar cut tool settings calculated against the shop
  profile; partial seat cuts use hand saw/chisel. Full-size pattern square
  verified at 72 pt in both directions on every page.
- PASS: CAD preview inspected; same frame topology and footprint, enlarged
  section and vertical proportion.
- NOT PHYSICALLY CHECKED: stock species, actual moisture, plywood thickness,
  drill/kerf, dry fit, final movement clearance and actual printed scale.
  Review these with scrap before cutting the production pieces.
- NOT QUANTIFIED: structural rating of a full-size building; this is a
  decorative miniature. Feather-edge minima were not exhaustively measured.
